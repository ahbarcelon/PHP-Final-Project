<section class="admin-shell shell-wide">
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <span class="logo-mark"><i class="bi bi-droplet-half"></i></span>
            <span><strong>HydraPatch</strong><small>Admin panel</small></span>
        </div>
        <button type="button" class="sidebar-toggle" aria-expanded="false" aria-label="Toggle admin menu"><i class="bi bi-list"></i> Menu</button>
        <div class="admin-profile"><b><?= e(strtoupper(substr($_SESSION['user']['fullname'], 0, 1))) ?></b><span><strong><?= e($_SESSION['user']['fullname']) ?></strong><small>Administrator</small></span></div>
        <nav>
            <a class="<?= $admin_section === 'dashboard' ? 'active' : '' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
            <a class="<?= $admin_section === 'products' ? 'active' : '' ?>" href="products.php"><i class="bi bi-box-seam"></i> Products & stock</a>
            <a class="<?= $admin_section === 'users' ? 'active' : '' ?>" href="users.php"><i class="bi bi-people"></i> User management</a>
            <a class="<?= $admin_section === 'reports' ? 'active' : '' ?>" href="reports.php"><i class="bi bi-clipboard-data"></i> Reports & audit</a>
            <a class="<?= $admin_section === 'analytics' ? 'active' : '' ?>" href="analytics.php"><i class="bi bi-graph-up-arrow"></i> Analytics</a>
            <a class="logout-link" href="<?= e($base_path) ?>logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>
        <small class="secure-admin"><i class="bi bi-shield-lock-fill"></i> SECURE ADMIN AREA</small>
    </aside>
    <div class="admin-main">
