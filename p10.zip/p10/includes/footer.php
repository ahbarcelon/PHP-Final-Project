</main>
<footer class="site-footer">
    <div class="footer-grid shell">
        <div>
            <span class="brand footer-brand"><span class="logo-mark"><i></i><b>⌁</b></span><span><strong>HydraPatch</strong><small>PH • TEAM AQUABYTE</small></span></span>
            <p>Smart hydration awareness for everyday Filipino life—an educational health-tech commerce concept.</p>
        </div>
        <div><strong>EXPLORE</strong><a href="<?= e($base_path) ?>shop.php">Shop all</a><a href="<?= e($base_path) ?>about.php">Our story</a><a href="<?= e($base_path) ?>register.php">Register</a></div>
        <div><strong>PROJECT</strong><span>Team AquaByte</span><span>BSIT • Year 2</span><span>Final project 2026</span></div>
    </div>
    <div class="disclaimer">“Disclaimer: This website is for educational purposes only and is a requirement for our final project.”</div>
</footer>

<!-- Sign-in Prompt Modal -->
<div class="auth-modal-overlay" id="authModal" aria-hidden="true" role="dialog">
    <div class="auth-modal">
        <h3 class="auth-modal-title">Join the HydraPatch Circle</h3>
        <p class="auth-modal-desc">You need to be signed in to add these smart formulas to your bag. Sign in or create an account to start your mindful hydration journey!</p>
        <div class="auth-modal-actions">
            <a href="<?= e($base_path) ?>register.php" class="auth-modal-btn btn-secondary">Create an Account</a>
            <a href="<?= e($base_path) ?>login.php" class="auth-modal-btn btn-primary">Sign In</a>
        </div>
    </div>
</div>

<script>
    window.isLoggedIn = <?= is_logged_in() ? 'true' : 'false' ?>;
</script>
<script src="<?= e($base_path) ?>assets/js/app.js"></script>
</body>
</html>
