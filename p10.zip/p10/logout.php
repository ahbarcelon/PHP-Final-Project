<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_logged_in()) {
    add_audit_log($pdo, $_SESSION['user']['user_id'], 'Logout', 'User ended the session.');
}

unset($_SESSION['user'], $_SESSION['checkout']);
session_regenerate_id(true);
set_flash('success', 'Logout');
redirect('index.php');
