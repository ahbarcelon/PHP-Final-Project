<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $user_id = filter_var($_POST['user_id'] ?? 0, FILTER_VALIDATE_INT);
    try {
        if ($action === 'add') {
            $fullname = trim($_POST['fullname'] ?? '');
            $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
            $password = $_POST['password'] ?? '';
            $role = in_array($_POST['role'] ?? '', ['customer', 'admin'], true) ? $_POST['role'] : 'customer';
            if (strlen($fullname) < 3 || !$email || strlen($password) < 8) throw new Exception('Complete the new-user form correctly.');
            $statement = $pdo->prepare('INSERT INTO users (fullname, email, password_hash, address, contact_number, role) VALUES (?, ?, ?, ?, ?, ?)');
            $statement->execute([$fullname, $email, password_hash($password, PASSWORD_DEFAULT), 'To be updated by user', '00000000000', $role]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'added user', "Added {$fullname} as {$role}.");
            set_flash('success', 'Record Added');
        } elseif ($action === 'role' && $user_id) {
            $role = in_array($_POST['role'] ?? '', ['customer', 'admin'], true) ? $_POST['role'] : 'customer';
            $statement = $pdo->prepare('UPDATE users SET role = ? WHERE user_id = ?');
            $statement->execute([$role, $user_id]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'changed user role', "Changed user #{$user_id} to {$role}.");
            set_flash('success', 'Record Updated');
        } elseif ($action === 'status' && $user_id && $user_id !== (int) $_SESSION['user']['user_id']) {
            $statement = $pdo->prepare('UPDATE users SET is_active = IF(is_active = 1, 0, 1) WHERE user_id = ?');
            $statement->execute([$user_id]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'updated access rights', "Toggled active status for user #{$user_id}.");
            set_flash('success', 'Record Updated');
        }
    } catch (Throwable $error) {
        set_flash('error', $error instanceof PDOException && $error->getCode() === '23000' ? 'That email already exists.' : $error->getMessage());
    }
    redirect('users.php');
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $statement = $pdo->prepare('SELECT * FROM users WHERE fullname LIKE ? OR email LIKE ? ORDER BY created_at DESC');
    $statement->execute(['%' . $search . '%', '%' . $search . '%']);
    $users = $statement->fetchAll();
} else {
    $users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll();
}

$page_title = 'User Management';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'users';
require __DIR__ . '/../includes/admin_header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">ROLES & ACCESS RIGHTS</span><h1>User management</h1></div><span class="record-badge">● <?= count($users) ?> accounts</span></header>
<?php if ($search !== ''): ?><div class="search-result">Search Result: <?= count($users) ?> user record(s)</div><?php endif; ?>
<div class="manage-grid">
    <section class="admin-card form-card"><span class="eyebrow">ADD ACCOUNT</span><h2>New user</h2><form class="admin-form" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add"><label>Complete name<input name="fullname" required></label><label>Email<input name="email" type="email" required></label><label>Temporary password<input name="password" type="password" minlength="8" required></label><label>Role<select name="role"><option value="customer">Customer</option><option value="admin">Admin</option></select></label><button class="button primary">Add user</button></form><div class="access-note"><strong>Access guide</strong><p>Admins manage inventory, users, reports, and audit logs. Customers shop and create orders.</p></div></section>
    <section class="admin-card table-card"><div class="card-title"><div><span class="eyebrow">ACCESS DIRECTORY</span><h2>Registered users</h2></div><form class="admin-search" method="get"><input name="q" value="<?= e($search) ?>" placeholder="Search users"><button>⌕</button></form></div><div class="table-wrap"><table><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Access</th></tr></thead><tbody><?php foreach ($users as $account): ?><tr><td><strong><?= e($account['fullname']) ?></strong><small><?= e($account['email']) ?></small></td><td><?= badge($account['role'], role_tone($account['role'])) ?></td><td><?= badge($account['is_active'] ? 'Active' : 'Inactive', user_status_tone($account['is_active'])) ?></td><td><?= e(date('M d, Y', strtotime($account['created_at']))) ?></td><td class="actions-cell"><div class="table-actions"><form method="post" title="Change role"><?= csrf_field() ?><input type="hidden" name="action" value="role"><input type="hidden" name="user_id" value="<?= (int) $account['user_id'] ?>"><select name="role" aria-label="Change role for <?= e($account['fullname']) ?>" onchange="this.form.submit()"><option value="customer" <?= $account['role'] === 'customer' ? 'selected' : '' ?>>Customer</option><option value="admin" <?= $account['role'] === 'admin' ? 'selected' : '' ?>>Admin</option></select><button type="submit" class="sr-only-submit">Save role</button></form><?php if ((int) $account['user_id'] !== (int) $_SESSION['user']['user_id']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="status"><input type="hidden" name="user_id" value="<?= (int) $account['user_id'] ?>"><button type="submit" class="icon-button <?= $account['is_active'] ? 'danger-icon' : 'success-icon' ?>" title="<?= $account['is_active'] ? 'Disable account' : 'Enable account' ?>" aria-label="<?= $account['is_active'] ? 'Disable' : 'Enable' ?> <?= e($account['fullname']) ?>"><i class="bi <?= $account['is_active'] ? 'bi-person-dash' : 'bi-person-check' ?>"></i></button></form><?php endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div></section>
</div>
<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/admin_footer.php'; ?>
