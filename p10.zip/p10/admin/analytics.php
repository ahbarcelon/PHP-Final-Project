<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

// ---- Sales trend: last 14 days, zero-filled ----
$statement = $pdo->prepare(
    "SELECT DATE(created_at) AS d, SUM(total_amount) AS total
     FROM orders
     WHERE order_status <> 'cancelled' AND created_at >= (CURDATE() - INTERVAL 13 DAY)
     GROUP BY DATE(created_at)"
);
$statement->execute();
$salesByDay = [];
foreach ($statement->fetchAll() as $row) {
    $salesByDay[$row['d']] = (float) $row['total'];
}
$trendLabels = [];
$trendValues = [];
for ($i = 13; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} day"));
    $trendLabels[] = date('M d', strtotime($date));
    $trendValues[] = round($salesByDay[$date] ?? 0, 2);
}
$trendTotal = array_sum($trendValues);
$spark = sparkline_points($trendValues, 560, 220, 30);

// Horizontal gridlines + y-axis labels for the sales trend chart (computed
// locally so functions.php / other pages stay untouched).
$trendMax = max(1, max($trendValues));
$gridSteps = 4;
$trendGridlines = [];
for ($g = 0; $g <= $gridSteps; $g++) {
    $value = $trendMax * ($g / $gridSteps);
    $y = $spark['height'] - 30 - (($value / $trendMax) * ($spark['height'] - 60));
    $trendGridlines[] = ['y' => round($y, 1), 'label' => format_price($value)];
}

// ---- Orders volume: last 14 days, zero-filled (new chart) ----
$statement2 = $pdo->prepare(
    "SELECT DATE(created_at) AS d, COUNT(*) AS c
     FROM orders
     WHERE order_status <> 'cancelled' AND created_at >= (CURDATE() - INTERVAL 13 DAY)
     GROUP BY DATE(created_at)"
);
$statement2->execute();
$ordersByDay = [];
foreach ($statement2->fetchAll() as $row) {
    $ordersByDay[$row['d']] = (int) $row['c'];
}
$orderTrendValues = [];
for ($i = 13; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} day"));
    $orderTrendValues[] = (int) ($ordersByDay[$date] ?? 0);
}
$orderTrendMax = max(1, max($orderTrendValues));
$orderTrendTotal = array_sum($orderTrendValues);
$barW = 560;
$barH = 220;
$barPad = 30;
$barGridlines = [];
for ($g = 0; $g <= $gridSteps; $g++) {
    $value = $orderTrendMax * ($g / $gridSteps);
    $y = $barH - $barPad - (($value / $orderTrendMax) * ($barH - $barPad * 2));
    $barGridlines[] = ['y' => round($y, 1), 'label' => (string) round($value)];
}
$barCount = count($orderTrendValues);
$barSlot = ($barW - $barPad * 2) / max(1, $barCount);
$barWidth = max(6, $barSlot * 0.55);

// ---- Order status breakdown ----
$statusRows = $pdo->query('SELECT order_status, COUNT(*) AS c FROM orders GROUP BY order_status ORDER BY c DESC')->fetchAll();
$statusLabels = array_map(fn($r) => ucfirst($r['order_status']), $statusRows);
$statusValues = array_map(fn($r) => (int) $r['c'], $statusRows);
$statusTotal = array_sum($statusValues);

// ---- Revenue by category ----
$categoryRows = $pdo->query(
    "SELECT c.category_name, COALESCE(SUM(oi.subtotal), 0) AS revenue
     FROM categories c
     LEFT JOIN products p ON p.category_id = c.category_id
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY c.category_name
     ORDER BY revenue DESC"
)->fetchAll();
$categoryLabels = array_column($categoryRows, 'category_name');
$categoryValues = array_map(fn($v) => round((float) $v, 2), array_column($categoryRows, 'revenue'));
$categoryMax = $categoryValues ? max($categoryValues) : 0;

// ---- Top products by units sold ----
$topProductRows = $pdo->query(
    "SELECT p.product_name, COALESCE(SUM(oi.quantity), 0) AS units
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY p.product_name
     ORDER BY units DESC
     LIMIT 6"
)->fetchAll();
$productLabels = array_map(fn($n) => str_replace('HydraPatch ', '', $n), array_column($topProductRows, 'product_name'));
$productValues = array_map('intval', array_column($topProductRows, 'units'));
$productMax = $productValues ? max($productValues) : 0;

// ---- Payment method split ----
$paymentRows = $pdo->query('SELECT payment_method, COUNT(*) AS c FROM orders GROUP BY payment_method ORDER BY c DESC')->fetchAll();
$paymentLabels = array_map(fn($r) => ucwords(str_replace('_', ' ', $r['payment_method'])), $paymentRows);
$paymentValues = array_map(fn($r) => (int) $r['c'], $paymentRows);
$paymentTotal = array_sum($paymentValues);

$hasOrders = (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn() > 0;
$palette = chart_palette();

// Local-only helper (kept in this file, not functions.php) that turns a set
// of values into interactive SVG donut segments using stroke-dasharray.
$donutSegments = function (array $values, array $colors, float $r = 60): array {
    $total = array_sum($values);
    $circumference = 2 * M_PI * $r;
    $segments = [];
    $offset = 0.0;
    foreach ($values as $i => $value) {
        $fraction = $total > 0 ? $value / $total : 0;
        $len = $fraction * $circumference;
        $segments[] = [
            'color' => $colors[$i % count($colors)],
            'dasharray' => sprintf('%.3f %.3f', $len, $circumference - $len),
            'dashoffset' => sprintf('%.3f', -$offset),
            'pct' => round($fraction * 100),
        ];
        $offset += $len;
    }
    return $segments;
};

$page_title = 'Analytics';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'analytics';
require __DIR__ . '/../includes/admin_header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">INSIGHTS & TRENDS</span><h1>Analytics</h1></div><a class="button small" href="reports.php">View reports</a></header>

<?php if (!$hasOrders): ?>
<section class="admin-card">
    <div class="chart-empty">
        <div><i class="bi bi-bar-chart" style="font-size:2rem;color:var(--muted);"></i><p style="margin-top:10px;">No order data yet. Charts will populate once orders come in.</p></div>
    </div>
</section>
<?php else: ?>
<div class="analytics-grid">

    <section class="admin-card chart-card wide">
        <div class="card-title"><div><span class="eyebrow">SALES TREND</span><h2>Last 14 days</h2></div><small>Total <?= format_price($trendTotal) ?></small></div>
        <svg class="trend-svg" viewBox="0 0 <?= $spark['width'] ?> <?= $spark['height'] ?>" preserveAspectRatio="none">
            <?php foreach ($trendGridlines as $line): ?>
                <line class="chart-gridline" x1="30" y1="<?= $line['y'] ?>" x2="<?= $spark['width'] - 10 ?>" y2="<?= $line['y'] ?>"></line>
                <text class="chart-grid-label" x="0" y="<?= $line['y'] + 4 ?>"><?= e($line['label']) ?></text>
            <?php endforeach; ?>
            <?php if ($spark['area'] !== ''): ?>
                <polygon points="<?= e($spark['area']) ?>" fill="rgba(15, 109, 141, 0.14)"></polygon>
                <polyline points="<?= e($spark['line']) ?>" fill="none" stroke="#0f6d8d" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></polyline>
                <?php foreach ($spark['points'] as $i => $point): ?>
                    <circle class="chart-point" cx="<?= $point[0] ?>" cy="<?= $point[1] ?>" r="10" fill="transparent" data-tip="<?= e(($trendLabels[$i] ?? '') . ' &middot; ' . format_price($trendValues[$i] ?? 0)) ?>"></circle>
                    <circle class="chart-point-dot" cx="<?= $point[0] ?>" cy="<?= $point[1] ?>" r="3.5" fill="#0f6d8d"></circle>
                <?php endforeach; ?>
            <?php endif; ?>
        </svg>
        <div class="trend-axis"><span><?= e($trendLabels[0] ?? '') ?></span><span><?= e($trendLabels[intdiv(count($trendLabels), 2)] ?? '') ?></span><span><?= e($trendLabels[count($trendLabels) - 1] ?? '') ?></span></div>
    </section>

    <section class="admin-card chart-card wide">
        <div class="card-title"><div><span class="eyebrow">ORDER VOLUME</span><h2>Orders per day, last 14 days</h2></div><small>Total <?= $orderTrendTotal ?> orders</small></div>
        <svg class="trend-svg" viewBox="0 0 <?= $barW ?> <?= $barH ?>" preserveAspectRatio="none">
            <?php foreach ($barGridlines as $line): ?>
                <line class="chart-gridline" x1="30" y1="<?= $line['y'] ?>" x2="<?= $barW - 10 ?>" y2="<?= $line['y'] ?>"></line>
                <text class="chart-grid-label" x="0" y="<?= $line['y'] + 4 ?>"><?= e($line['label']) ?></text>
            <?php endforeach; ?>
            <?php foreach ($orderTrendValues as $i => $value):
                $x = $barPad + $barSlot * $i + ($barSlot - $barWidth) / 2;
                $h = $orderTrendMax > 0 ? ($value / $orderTrendMax) * ($barH - $barPad * 2) : 0;
                $y = $barH - $barPad - $h;
            ?>
                <rect class="chart-bar" x="<?= round($x, 1) ?>" y="<?= round($y, 1) ?>" width="<?= round($barWidth, 1) ?>" height="<?= round($h, 1) ?>" rx="3" fill="#8be0c5" data-tip="<?= e(($trendLabels[$i] ?? '') . ' &middot; ' . $value . ' order' . ($value === 1 ? '' : 's')) ?>"></rect>
            <?php endforeach; ?>
        </svg>
        <div class="trend-axis"><span><?= e($trendLabels[0] ?? '') ?></span><span><?= e($trendLabels[intdiv(count($trendLabels), 2)] ?? '') ?></span><span><?= e($trendLabels[count($trendLabels) - 1] ?? '') ?></span></div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">ORDER PIPELINE</span><h2>Status breakdown</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut">
                <svg class="donut-svg" viewBox="0 0 150 150">
                    <circle cx="75" cy="75" r="60" fill="none" stroke="#e7edf0" stroke-width="24"></circle>
                    <?php foreach ($donutSegments($statusValues, $palette) as $i => $seg): ?>
                        <circle class="donut-segment" data-index="<?= $i ?>" cx="75" cy="75" r="60" fill="none" stroke="<?= e($seg['color']) ?>" stroke-width="24" stroke-dasharray="<?= $seg['dasharray'] ?>" stroke-dashoffset="<?= $seg['dashoffset'] ?>" transform="rotate(-90 75 75)" data-tip="<?= e(($statusLabels[$i] ?? '') . ' &middot; ' . $statusValues[$i] . ' (' . $seg['pct'] . '%)') ?>"></circle>
                    <?php endforeach; ?>
                </svg>
                <div class="donut-total"><strong><?= $statusTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($statusLabels as $i => $label): ?>
                    <li data-index="<?= $i ?>"><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $statusValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$statusLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">CHECKOUT</span><h2>Payment method split</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut">
                <svg class="donut-svg" viewBox="0 0 150 150">
                    <circle cx="75" cy="75" r="60" fill="none" stroke="#e7edf0" stroke-width="24"></circle>
                    <?php foreach ($donutSegments($paymentValues, $palette) as $i => $seg): ?>
                        <circle class="donut-segment" data-index="<?= $i ?>" cx="75" cy="75" r="60" fill="none" stroke="<?= e($seg['color']) ?>" stroke-width="24" stroke-dasharray="<?= $seg['dasharray'] ?>" stroke-dashoffset="<?= $seg['dashoffset'] ?>" transform="rotate(-90 75 75)" data-tip="<?= e(($paymentLabels[$i] ?? '') . ' &middot; ' . $paymentValues[$i] . ' (' . $seg['pct'] . '%)') ?>"></circle>
                    <?php endforeach; ?>
                </svg>
                <div class="donut-total"><strong><?= $paymentTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($paymentLabels as $i => $label): ?>
                    <li data-index="<?= $i ?>"><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $paymentValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$paymentLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">REVENUE MIX</span><h2>By category</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($categoryLabels as $i => $label): $pct = $categoryMax > 0 ? round(($categoryValues[$i] / $categoryMax) * 100) : 0; ?>
                <div class="metric-bar-row" data-tip="<?= e($label . ' &middot; ' . format_price($categoryValues[$i]) . ' (' . $pct . '%)') ?>"><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= format_price($categoryValues[$i]) ?></strong></div>
            <?php endforeach; ?>
            <?php if (!$categoryLabels): ?><p>No category data yet.</p><?php endif; ?>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">BEST SELLERS</span><h2>Top products by units sold</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($productLabels as $i => $label): $pct = $productMax > 0 ? round(($productValues[$i] / $productMax) * 100) : 0; ?>
                <div class="metric-bar-row" data-tip="<?= e($label . ' &middot; ' . $productValues[$i] . ' units (' . $pct . '%)') ?>"><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= $productValues[$i] ?> units</strong></div>
            <?php endforeach; ?>
            <?php if (!$productLabels): ?><p>No sales data yet.</p><?php endif; ?>
        </div>
    </section>

</div>
<div id="chartTooltip" class="chart-tooltip" role="tooltip" hidden></div>
<script>
(function () {
    var tip = document.getElementById('chartTooltip');
    if (!tip) return;

    function showTip(el, evt) {
        var text = el.getAttribute('data-tip');
        if (!text) return;
        tip.innerHTML = text;
        tip.hidden = false;
        moveTip(evt);
        var index = el.getAttribute('data-index');
        if (index !== null) {
            document.querySelectorAll('[data-index="' + index + '"]').forEach(function (n) {
                n.classList.add('is-active');
            });
        } else {
            el.classList.add('is-active');
        }
    }

    function moveTip(evt) {
        if (!evt || typeof evt.clientX !== 'number') return;
        var x = evt.clientX + 14;
        var y = evt.clientY + 14;
        var maxX = window.innerWidth - tip.offsetWidth - 12;
        var maxY = window.innerHeight - tip.offsetHeight - 12;
        tip.style.left = Math.min(x, Math.max(12, maxX)) + 'px';
        tip.style.top = Math.min(y, Math.max(12, maxY)) + 'px';
    }

    function hideTip() {
        tip.hidden = true;
        document.querySelectorAll('.is-active').forEach(function (n) {
            n.classList.remove('is-active');
        });
    }

    document.querySelectorAll('[data-tip]').forEach(function (el) {
        el.addEventListener('mouseenter', function (evt) { showTip(el, evt); });
        el.addEventListener('mousemove', moveTip);
        el.addEventListener('mouseleave', hideTip);
        el.setAttribute('tabindex', el.getAttribute('tabindex') || '0');
        el.addEventListener('focus', function (evt) { showTip(el, evt); });
        el.addEventListener('blur', hideTip);
    });

    // Legend items highlight their matching donut segment too.
    document.querySelectorAll('.chart-legend-list li[data-index]').forEach(function (li) {
        li.addEventListener('mouseenter', function () {
            var index = li.getAttribute('data-index');
            document.querySelectorAll('[data-index="' + index + '"]').forEach(function (n) {
                n.classList.add('is-active');
            });
        });
        li.addEventListener('mouseleave', hideTip);
    });
})();
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/admin_footer.php'; ?>
