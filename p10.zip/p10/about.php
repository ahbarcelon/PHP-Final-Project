<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Our Story';
$active_page = 'about';
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page">
    <header class="page-heading"><span class="eyebrow">OUR STORY</span><h1>A small patch concept with a big everyday purpose.</h1><p>HydraPatch PH is Team AquaByte's educational health-tech commerce project—created to make wellness technology feel approachable, useful, and local.</p></header>
    <div class="story-grid">
        <div class="story-visual">
            <?php
                $visual_category = 'OFFICE'; $visual_tone = 'blue';
                $image_file = $category_images[strtolower($visual_category)] ?? null;
            ?>
            <div class="product-visual tone-<?= e($visual_tone) ?>">
                <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="Office patch concept"><?php endif; ?>
            </div>
            <small>CONCEPT / 2026</small>
        </div>
        <div><span class="eyebrow">WHY HYDRAPATCH</span><h2>Healthy routines should feel natural.</h2><p>Busy schedules make it easy to forget the basics. Our concept explores how a lightweight wearable cue can make hydration awareness feel more consistent.</p><div class="mission-grid"><article><b>MISSION</b><p>Design approachable wellness tools that support mindful everyday habits.</p></article><article><b>VISION</b><p>A future where practical health technology supports every Filipino lifestyle.</p></article></div></div>
    </div>
    <section class="team-section"><span class="eyebrow">THE PEOPLE BEHIND THE PROJECT</span><h2>Team AquaByte</h2><div class="team-grid"><article><b>AS</b><strong> Aaron Barcelon</strong><small> Project lead</small></article><article><b>LM</b><strong> Shem Caayon</strong><small> Backend developer</small></article><article><b>MR</b><strong> Isabella Guevarra</strong><small> Front-end Developer</small></article><article><b>PC</b><strong> Lei Gonzales</strong><small> Database lead</small></article></div></section>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>