<?php
require_once __DIR__ . '/includes/bootstrap.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fullname = trim($_POST['fullname'] ?? '');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $address = trim($_POST['address'] ?? '');
    $contact = preg_replace('/[^0-9+ ]/', '', $_POST['contact_number'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($fullname) < 3) $errors[] = 'Please enter your complete name.';
    if (!$email) $errors[] = 'Please enter a valid email address.';
    if (strlen($address) < 10) $errors[] = 'Please enter your complete address.';
    if (strlen($contact) < 10) $errors[] = 'Please enter a valid contact number.';
    if (strlen($password) < 8) $errors[] = 'Password must contain at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        try {
            $statement = $pdo->prepare('INSERT INTO users (fullname, email, password_hash, address, contact_number) VALUES (?, ?, ?, ?, ?)');
            $statement->execute([$fullname, $email, password_hash($password, PASSWORD_DEFAULT), $address, $contact]);
            @mail($email, 'Welcome to HydraPatch PH', "Hello {$fullname}, your educational project account has been confirmed.");
            set_flash('success', 'Record Added — registration complete. A confirmation email was queued.');
            redirect('login.php');
        } catch (PDOException $error) {
            $errors[] = $error->getCode() === '23000' ? 'That email address is already registered.' : 'Registration could not be completed.';
        }
    }
}

$page_title = 'Create Account';
require __DIR__ . '/includes/header.php';
?>
<section class="auth-page shell">
    <div class="auth-card">
        <!-- Left Panel: Welcome and Brand Overview -->
        <div class="auth-info-panel">
            <div class="auth-logo-placeholder">
                <span class="logo-mark"><i></i><b>⌁</b></span>
                <strong>HydraPatch</strong>
            </div>
            
            <div class="auth-info-content">
                <span class="eyebrow">TEAM AQUABYTE</span>
                <h2>Start a more mindful routine.</h2>
                <p>HydraPatch PH is a smart health-tech concept designed to help you track hydration and maintain a healthier lifestyle with daily cues. Join a wellness concept made for real Filipino lifestyles.</p>
            </div>
            
            <!-- Decorative shapes -->
            <div class="auth-deco-circle-1"></div>
            <div class="auth-deco-circle-2"></div>
        </div>

        <!-- Right Panel: Registration Form -->
        <form class="auth-form" method="post" novalidate>
            <?= csrf_field() ?>
            <span class="eyebrow">CREATE YOUR ACCOUNT</span>
            <h1>Let’s get you started.</h1>
            <p>All fields are required. A confirmation email is queued after registration.</p>
            <?php if ($errors): ?>
                <div class="error-list">
                    <?php foreach ($errors as $error): ?>
                        <span><?= e($error) ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="form-grid">
                <label>Complete name<input name="fullname" required value="<?= old('fullname') ?>"></label>
                <label>Valid email<input name="email" type="email" required value="<?= old('email') ?>"></label>
            </div>
            <label>Complete address<textarea name="address" required><?= old('address') ?></textarea></label>
            <label>Contact number<input name="contact_number" required value="<?= old('contact_number') ?>" pattern="[0-9+ ]{10,18}"></label>
            <div class="form-grid">
                <label>Password<input name="password" type="password" minlength="8" required></label>
                <label>Confirm password<input name="confirm_password" type="password" minlength="8" required></label>
            </div>
            <button class="button primary" type="submit">Create account →</button>
            <p class="switch-link">Already registered? <a href="login.php">Sign in</a></p>
        </form>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>