<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login('login.php');

$user_id = $_SESSION['user']['user_id'];

// Handle POST actions (cancellation and archiving)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $order_id = filter_var($_POST['order_id'] ?? 0, FILTER_VALIDATE_INT);
    
    if ($order_id) {
        try {
            // Verify that the order belongs to this customer
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ?");
            $stmt->execute([$order_id, $user_id]);
            $order = $stmt->fetch();
            
            if (!$order) {
                throw new Exception('Order record not found.');
            }
            
            if ($action === 'archive_order') {
                if ($order['order_status'] !== 'completed' && $order['order_status'] !== 'cancelled') {
                    throw new Exception('Only completed or cancelled orders can be removed.');
                }
                $stmt = $pdo->prepare("UPDATE orders SET customer_archived = 1 WHERE order_id = ?");
                $stmt->execute([$order_id]);
                set_flash('success', 'Order removed from your list.');
                
            } elseif ($action === 'cancel_order') {
                if ($order['order_status'] !== 'pending' && $order['order_status'] !== 'processing') {
                    throw new Exception('This order is already prepared or shipped and cannot be cancelled.');
                }
                
                $pdo->beginTransaction();
                
                // Update statuses to cancelled
                $stmt = $pdo->prepare("UPDATE orders SET order_status = 'cancelled', payment_status = 'cancelled' WHERE order_id = ?");
                $stmt->execute([$order_id]);
                
                // Fetch items to restore stock
                $item_stmt = $pdo->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
                $item_stmt->execute([$order_id]);
                $items = $item_stmt->fetchAll();
                
                $update_stock = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + ?, status = 'available' WHERE product_id = ?");
                foreach ($items as $item) {
                    $update_stock->execute([$item['quantity'], $item['product_id']]);
                }
                
                add_audit_log($pdo, $user_id, 'cancelled order', "Customer cancelled order {$order['order_code']} and returned stock.");
                
                $pdo->commit();
                set_flash('success', 'Order cancelled successfully.');
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            set_flash('error', $e->getMessage());
        }
    }
    redirect('purchases.php');
}

// Fetch all visible orders for this user
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? AND customer_archived = 0 ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();

// Category image map for visual consistency
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];

$page_title = 'My Purchases';
$active_page = 'purchases';
require __DIR__ . '/includes/header.php';
?>

<section class="shell standard-page">
    <header class="page-heading">
        <span class="eyebrow">ORDER TRACKING</span>
        <h1>My Purchases</h1>
        <p>Monitor your active order shipments and view past order history records.</p>
    </header>

    <div class="purchases-grid">
        <?php if (!$orders): ?>
            <div class="empty-state">
                <b>○</b>
                <h2>No purchases yet.</h2>
                <p>Start your mindful hydration journey today by exploring our smart formula patches.</p>
                <a class="button primary" href="shop.php">Start shopping →</a>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
                <?php
                // Fetch items for this order
                $item_stmt = $pdo->prepare("
                    SELECT oi.*, p.product_name, p.product_image, c.category_name 
                    FROM order_items oi 
                    JOIN products p ON p.product_id = oi.product_id 
                    JOIN categories c ON c.category_id = p.category_id 
                    WHERE oi.order_id = ?
                ");
                $item_stmt->execute([$order['order_id']]);
                $items = $item_stmt->fetchAll();

                $status = $order['order_status'];
                $is_cancelled = ($status === 'cancelled');

                // Mapping statuses to step indexes
                $status_map = [
                    'pending' => 0,
                    'processing' => 1,
                    'packed' => 2,
                    'shipped' => 3,
                    'for_delivery' => 4,
                    'completed' => 5
                ];
                $current_step = $status_map[$status] ?? 0;
                $progress_pct = ($current_step / 5) * 100;
                ?>
                <details class="purchase-details-toggle">
                    <summary class="purchase-card-summary">
                        <div class="summary-col-id">
                            <h3><?= e($order['order_code']) ?></h3>
                            <small>Placed on <?= e(date('F d, Y \a\t g:i A', strtotime($order['created_at']))) ?></small>
                        </div>
                        <div class="summary-col-items">
                            <?php
                            $item_summaries = [];
                            foreach ($items as $item) {
                                $short_name = str_replace('HydraPatch ', '', $item['product_name']);
                                $item_summaries[] = $short_name . ' ×' . $item['quantity'];
                            }
                            echo e(implode(', ', $item_summaries));
                            ?>
                        </div>
                        <div class="summary-col-badges">
                            <?= badge(str_replace('_', ' ', $status), order_status_tone($status)) ?>
                            <?= badge($order['payment_status'], payment_status_tone($order['payment_status'])) ?>
                        </div>
                        <div class="summary-col-price">
                            <span><?= format_price($order['total_amount']) ?></span>
                            <span class="expand-icon"><i class="bi bi-chevron-down"></i></span>
                        </div>
                    </summary>

                    <div class="purchase-card-body">
                        <?php if ($is_cancelled): ?>
                            <div class="flash flash-error" style="margin: 0; position: relative; width: 100%;">
                                <b>✕</b> This order has been cancelled and will not be processed further.
                            </div>
                        <?php else: ?>
                            <!-- Visual Tracker Timeline -->
                            <div class="tracking-timeline-box">
                                <h4>Delivery Progress Timeline</h4>
                                <div class="stepper-timeline">
                                    <div class="stepper-progress-bar" style="width: <?= $progress_pct ?>%"></div>
                                    
                                    <?php
                                    $steps = [
                                        ['label' => 'Order Placed', 'icon' => 'bi-receipt', 'desc' => 'We received your order.'],
                                        ['label' => 'Processing', 'icon' => 'bi-gear', 'desc' => 'Preparing your items.'],
                                        ['label' => 'Packed & Ready', 'icon' => 'bi-box-seam', 'desc' => 'Packed and ready for courier pickup.'],
                                        ['label' => 'Shipped Out', 'icon' => 'bi-truck', 'desc' => 'Handed over to our courier.'],
                                        ['label' => 'For Delivery', 'icon' => 'bi-house-door', 'desc' => 'Courier is delivering today.'],
                                        ['label' => 'Completed', 'icon' => 'bi-check2-all', 'desc' => 'Delivered to recipient.']
                                    ];
                                    ?>
                                    <?php foreach ($steps as $idx => $step): ?>
                                        <?php
                                        $step_class = '';
                                        if ($idx === $current_step) {
                                            $step_class = 'active';
                                        } elseif ($idx < $current_step) {
                                            $step_class = 'completed';
                                        }
                                        ?>
                                        <div class="stepper-step <?= $step_class ?>">
                                            <div class="stepper-icon">
                                                <?php if ($idx < $current_step): ?>
                                                    <i class="bi bi-check"></i>
                                                <?php else: ?>
                                                    <i class="bi <?= $step['icon'] ?>"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="stepper-step-content">
                                                <span class="stepper-label"><?= e($step['label']) ?></span>
                                                <span class="stepper-desc"><?= e($step['desc']) ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="purchase-card-meta">
                            <div>
                                <span>DELIVERY DETAILS</span><br>
                                <strong><?= e($_SESSION['user']['fullname']) ?></strong><br>
                                <span>Phone: <?= e($order['contact_number']) ?></span><br>
                                <span>Address: <?= e($order['shipping_address']) ?></span>
                            </div>
                            <div>
                                <span>PAYMENT INFO</span><br>
                                <span>Method: <strong><?= e(ucwords(str_replace('_', ' ', $order['payment_method']))) ?></strong></span><br>
                                <span>Status: <strong><?= e(ucfirst($order['payment_status'])) ?></strong></span><br>
                                <span>Total Charge: <strong style="color: var(--primary); font-size: 1.1rem;"><?= format_price($order['total_amount']) ?></strong></span>
                            </div>
                        </div>

                        <div class="order-details-items">
                            <h4>Items Purchased</h4>
                            <div class="purchase-items-list">
                                <?php foreach ($items as $idx => $item): ?>
                                    <?php
                                    $image_key = strtolower(str_replace(' ', '', $item['category_name']));
                                    $image_file = $category_images[$image_key] ?? null;
                                    $visual_tone = ['aqua','violet','lime','blue','coral'][$idx % 5];
                                    ?>
                                    <div class="purchase-item-row">
                                        <div class="purchase-item-info">
                                            <div class="purchase-item-image-box tone-<?= e($visual_tone) ?>" style="width: 80px; height: 80px; min-width: 80px; min-height: 80px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; overflow: hidden; padding: 6px; border: 1px solid var(--line); flex-shrink: 0;">
                                                <?php if ($image_file): ?>
                                                    <img class="product-photo" src="products/<?= e($image_file) ?>" alt="<?= e($item['product_name']) ?>" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                                <?php endif; ?>
                                            </div>
                                            <div class="purchase-item-details">
                                                <span class="purchase-item-name"><?= e($item['product_name']) ?></span>
                                                <span class="purchase-item-qty">Qty: <?= (int) $item['quantity'] ?> × <?= format_price($item['unit_price']) ?></span>
                                            </div>
                                        </div>
                                        <strong><?= format_price($item['subtotal']) ?></strong>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <!-- Order Actions: Cancel or Archive -->
                        <div style="border-top: 1px solid var(--line); padding-top: 16px; display: flex; justify-content: flex-end; gap: 12px; margin-top: 20px;">
                            <?php if ($order['order_status'] === 'pending' || $order['order_status'] === 'processing'): ?>
                                <form method="post" style="margin: 0;" onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="cancel_order">
                                    <input type="hidden" name="order_id" value="<?= (int) $order['order_id'] ?>">
                                    <button type="submit" class="button small" style="border: none; cursor: pointer; background: var(--error); color: var(--error-text); padding: 8px 16px; font-weight: 700; border-radius: var(--radius-sm); transition: transform 0.2s;">
                                        <i class="bi bi-x-circle"></i> Cancel Order
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <?php if ($order['order_status'] === 'completed' || $order['order_status'] === 'cancelled'): ?>
                                <form method="post" style="margin: 0;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="archive_order">
                                    <input type="hidden" name="order_id" value="<?= (int) $order['order_id'] ?>">
                                    <button type="submit" class="button secondary small" style="border: none; cursor: pointer; padding: 8px 16px; font-weight: 700; border-radius: var(--radius-sm); transition: transform 0.2s;" onclick="return confirm('Remove this order from your list? You will no longer see it here.')">
                                        <i class="bi bi-archive"></i> Remove from List
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </details>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
