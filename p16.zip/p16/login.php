<?php
require_once __DIR__ . '/includes/bootstrap.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || $password === '') {
        $error = 'Enter a valid email and password.';
    } else {
        $statement = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $account = $statement->fetch();

        if ($account && (int) $account['is_active'] === 1 && password_verify($password, $account['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'user_id' => $account['user_id'],
                'fullname' => $account['fullname'],
                'email' => $account['email'],
                'role' => $account['role'],
            ];

            // --- CART RESTORATION LOGIC START ---
            $cart_stmt = $pdo->prepare("SELECT cart_data FROM cart_persistence WHERE user_id = ?");
            $cart_stmt->execute([$account['user_id']]);
            $saved_cart = $cart_stmt->fetchColumn();

            if ($saved_cart) {
                $decoded_cart = json_decode($saved_cart, true);
                if (is_array($decoded_cart)) {
                    // Merge saved database cart with any items added during the current guest session
                    $current_cart = $_SESSION['cart'] ?? [];
                    foreach ($decoded_cart as $prod_id => $qty) {
                        $current_cart[$prod_id] = isset($current_cart[$prod_id]) 
                            ? $current_cart[$prod_id] + $qty 
                            : $qty;
                    }
                    $_SESSION['cart'] = $current_cart;
                }
                // Clear the persistence table since the cart is now active in the session
                $delete_stmt = $pdo->prepare("DELETE FROM cart_persistence WHERE user_id = ?");
                $delete_stmt->execute([$account['user_id']]);
            }
            // --- CART RESTORATION LOGIC END ---

            add_audit_log($pdo, $account['user_id'], 'Login Success', 'User signed in successfully.');
            set_flash('success', 'Login Success');
            redirect($account['role'] === 'admin' ? 'admin/dashboard.php' : 'shop.php');
        }
        $error = 'Incorrect credentials or inactive account.';
    }
}

$page_title = 'Login';
require __DIR__ . '/includes/header.php';
?>
<section class="auth-page shell login-page">
    <div class="auth-card">
        <!-- Left Panel: Welcome and Brand Overview -->
        <div class="auth-info-panel">
            <div class="auth-logo-placeholder">
    <img class="logo-mark" src="Logos/Logo.jpg" alt="HydraPatch PH logo">
    <strong>HydraPatch</strong>
</div>
            
            <div class="auth-info-content">
                <span class="eyebrow">TEAM AQUABYTE</span>
                <h2>Small cues can create healthier days.</h2>
                <p>HydraPatch PH is a smart health-tech concept designed to help you track hydration and maintain a healthier lifestyle with daily cues. Sign in to shop, access your cart, orders, or manage the project.</p>
            </div>
            
            <!-- Decorative shapes -->
            <div class="auth-deco-circle-1"></div>
            <div class="auth-deco-circle-2"></div>
        </div>

        <!-- Right Panel: Login Form -->
        <form class="auth-form" method="post">
            <?= csrf_field() ?>
            <span class="eyebrow">WELCOME BACK</span>
            <h1>Sign in to continue.</h1>
            <p>Access your cart, orders, or seller dashboard.</p>
            <?php if ($error): ?>
                <div class="error-list"><span><?= e($error) ?></span></div>
            <?php endif; ?>
            <label>Email address<input name="email" required type="email" value="<?= old('email') ?>"></label>
            <label>Password<input name="password" required type="password" minlength="8"></label>
            <button class="button primary" type="submit">Sign in securely →</button>
            <p class="switch-link">New to HydraPatch? <a href="register.php">Create an account</a></p>
        </form>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>