<?php
require_once __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $product_id = filter_var($_POST['product_id'] ?? 0, FILTER_VALIDATE_INT);
    $_SESSION['cart'] = $_SESSION['cart'] ?? [];

    if ($action === 'add' && $product_id) {
        require_login();
        $statement = $pdo->prepare("SELECT product_id FROM products WHERE product_id = ? AND status = 'available' AND stock_quantity > 0");
        $statement->execute([$product_id]);
        if ($statement->fetch()) {
            $_SESSION['cart'][$product_id] = ($_SESSION['cart'][$product_id] ?? 0) + 1;
            set_flash('success', 'Product added to cart.');
        }
        redirect_back();
    } elseif ($action === 'update' && !empty($_POST['quantity']) && is_array($_POST['quantity'])) {
        $updated_id = null;
        foreach ($_POST['quantity'] as $id => $quantity) {
            $safe_id = filter_var($id, FILTER_VALIDATE_INT);
            $safe_quantity = max(1, min(99, (int) $quantity));
            if ($safe_id && isset($_SESSION['cart'][$safe_id])) {
                $_SESSION['cart'][$safe_id] = $safe_quantity;
                $updated_id = $safe_id;
            }
        }
        set_flash('success', 'Record Updated');
        redirect('cart.php' . ($updated_id ? '#item-' . $updated_id : ''));
    } elseif ($action === 'remove' && $product_id) {
        unset($_SESSION['cart'][$product_id]);
        set_flash('success', 'Record Deleted');
    } elseif ($action === 'checkout') {
        $checked_items = $_POST['checked_items'] ?? [];
        if (empty($checked_items)) {
            set_flash('error', 'Select at least one item to checkout.');
            redirect('cart.php');
        }
        $_SESSION['checkout_items'] = array_map('intval', $checked_items);
        redirect('checkout.php');
    }
    redirect('cart.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    unset($_SESSION['checkout_items']);
}

$cart = $_SESSION['cart'] ?? [];
$products = [];
$subtotal = 0;
if ($cart) {
    $ids = array_map('intval', array_keys($cart));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $statement = $pdo->prepare("SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id WHERE p.product_id IN ({$placeholders})");
    $statement->execute($ids);
    $products = $statement->fetchAll();
    foreach ($products as $product) $subtotal += $product['price'] * $cart[$product['product_id']];
}
$shipping = $subtotal > 0 ? 89 : 0;
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];
$page_title = 'Cart';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page narrow-page">
    <header class="page-heading"><span class="eyebrow">YOUR BAG</span><h1>Cart (<?= cart_count() ?>)</h1><p>Review your patches, adjust quantities, and continue when everything looks right.</p></header>
    <div class="cart-layout">
        <div class="cart-list">
            <?php if (!$products): ?><div class="empty-state"><b>○</b><h2>Your cart is ready for a fresh start.</h2><a class="button primary" href="shop.php">Browse products</a></div><?php endif; ?>
            <?php foreach ($products as $index => $product): ?>
                <?php
                    $item_price_total = $product['price'] * $cart[$product['product_id']];
                ?>
                <article class="cart-item" id="item-<?= (int) $product['product_id'] ?>">
                    <input type="checkbox" name="checked_items[]" value="<?= (int) $product['product_id'] ?>" checked class="cart-item-checkbox" form="checkoutForm" data-price="<?= $item_price_total ?>">
                    <div class="cart-item-content">
                        <?php
                            $visual_tone = ['aqua','violet','lime','blue','coral'][$index % 5];
                            $image_key = strtolower(str_replace(' ', '', $product['category_name']));
                            $image_file = $category_images[$image_key] ?? null;
                        ?>
                        <div class="product-visual tone-<?= e($visual_tone) ?>">
                            <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="<?= e($product['product_name']) ?>"><?php endif; ?>
                        </div>
                        <div><small><?= e(strtoupper($product['category_name'])) ?></small><h3><?= e($product['product_name']) ?></h3><span><?= (int) $product['stock_quantity'] ?> in stock</span><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button class="remove-button">Remove</button></form></div>
                        <form class="quantity-form" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="number" name="quantity[<?= (int) $product['product_id'] ?>]" min="1" max="<?= (int) $product['stock_quantity'] ?>" value="<?= (int) $cart[$product['product_id']] ?>"><button>Update</button></form>
                        <strong><?= format_price($item_price_total) ?></strong>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <aside class="order-summary">
            <span class="eyebrow">ORDER SUMMARY</span>
            <h2>Ready when you are.</h2>
            <p><span>Subtotal</span><strong id="summary-subtotal"><?= format_price($subtotal) ?></strong></p>
            <p><span>Shipping</span><strong id="summary-shipping"><?= $shipping ? format_price($shipping) : '—' ?></strong></p>
            <div><span>Total</span><strong id="summary-total"><?= format_price($subtotal + $shipping) ?></strong></div>
            <?php if ($products): ?>
                <button type="submit" class="button primary" id="checkout-btn" form="checkoutForm" style="width: 100%; border: none; cursor: pointer;">Continue to checkout</button>
            <?php endif; ?>
            <small>▣ Secure classroom-demo checkout</small>
        </aside>
    </div>
</section>

<!-- Main Checkout Form associated with checkboxes and checkout button -->
<form id="checkoutForm" method="post" action="cart.php">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="checkout">
</form>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const checkboxes = document.querySelectorAll(".cart-item-checkbox");
    const subtotalEl = document.getElementById("summary-subtotal");
    const shippingEl = document.getElementById("summary-shipping");
    const totalEl = document.getElementById("summary-total");
    const checkoutBtn = document.getElementById("checkout-btn");

    if (checkboxes.length > 0 && subtotalEl && shippingEl && totalEl) {
        const updateSummary = () => {
            let subtotal = 0;
            let checkedCount = 0;
            checkboxes.forEach(cb => {
                if (cb.checked) {
                    subtotal += parseFloat(cb.dataset.price || 0);
                    checkedCount++;
                }
            });

            const shipping = subtotal > 0 ? 89 : 0;
            const total = subtotal + shipping;

            // Currency formatting helper
            const formatPHP = (amount) => {
                return "₱" + amount.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            };

            subtotalEl.textContent = formatPHP(subtotal);
            shippingEl.textContent = shipping > 0 ? formatPHP(shipping) : "—";
            totalEl.textContent = formatPHP(total);

            if (checkoutBtn) {
                if (checkedCount === 0) {
                    checkoutBtn.disabled = true;
                    checkoutBtn.style.opacity = "0.5";
                    checkoutBtn.style.pointerEvents = "none";
                } else {
                    checkoutBtn.disabled = false;
                    checkoutBtn.style.opacity = "";
                    checkoutBtn.style.pointerEvents = "";
                }
            }
        };

        checkboxes.forEach(cb => {
            cb.addEventListener("change", updateSummary);
        });

        // Initial update
        updateSummary();
    }
});
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>