<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();

$user_id = $_SESSION['user']['user_id'];
$errors = [];

// Fetch latest user info from DB
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    set_flash('error', 'User account not found.');
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $username = trim($_POST['username'] ?? '');
        $fullname = trim($_POST['fullname'] ?? '');
        $address = trim($_POST['address'] ?? '');
        
        // Validation
        if ($username !== '') {
            if (!preg_match('/^[a-zA-Z0-9_\-]{3,30}$/', $username)) {
                $errors[] = 'Username must be 3-30 characters long and can only contain letters, numbers, hyphens, and underscores.';
            } else {
                $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
                $stmt->execute([$username, $user_id]);
                if ($stmt->fetch()) {
                    $errors[] = 'That username is already taken.';
                }
            }
        } else {
            $username = null;
        }
        
        if (strlen($fullname) < 3) {
            $errors[] = 'Complete name must contain at least 3 characters.';
        }
        
        if (strlen($address) < 10) {
            $errors[] = 'Complete address must contain at least 10 characters.';
        }
        
        // Handle profile picture
        $profile_picture = $user['profile_picture'];
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['profile_picture']['tmp_name'];
            $file_name = $_FILES['profile_picture']['name'];
            $file_size = $_FILES['profile_picture']['size'];
            $file_type = $_FILES['profile_picture']['type'];
            
            if ($file_size > 5 * 1024 * 1024) {
                $errors[] = 'Profile picture must be smaller than 5MB.';
            } else {
                $allowed_types = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
                if (!in_array($file_type, $allowed_types)) {
                    $errors[] = 'Invalid file format. Only PNG, JPG, GIF, and WebP are allowed.';
                } else {
                    $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'gif', 'webp'])) {
                        $errors[] = 'Invalid file extension.';
                    } else {
                        $upload_dir = 'uploads/profile/';
                        if (!is_dir(__DIR__ . '/' . $upload_dir)) {
                            mkdir(__DIR__ . '/' . $upload_dir, 0755, true);
                        }
                        
                        $new_filename = 'user_' . $user_id . '_' . time() . '.' . $ext;
                        $target_path = $upload_dir . $new_filename;
                        
                        if (move_uploaded_file($file_tmp, __DIR__ . '/' . $target_path)) {
                            if ($user['profile_picture'] && file_exists(__DIR__ . '/' . $user['profile_picture'])) {
                                @unlink(__DIR__ . '/' . $user['profile_picture']);
                            }
                            $profile_picture = $target_path;
                        } else {
                            $errors[] = 'Failed to save the uploaded image.';
                        }
                    }
                }
            }
        }
        
        if (empty($errors)) {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, fullname = ?, address = ?, profile_picture = ? WHERE user_id = ?");
            $stmt->execute([$username, $fullname, $address, $profile_picture, $user_id]);
            
            $_SESSION['user']['fullname'] = $fullname;
            
            add_audit_log($pdo, $user_id, 'Profile Update', 'User updated their personal information.');
            set_flash('success', 'Profile updated successfully.');
            redirect('profile.php');
        }
        
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Verify current password
        if (!password_verify($current_password, $user['password_hash'])) {
            $errors[] = 'The current password you entered is incorrect.';
        }
        
        if (strlen($new_password) < 8) {
            $errors[] = 'New password must contain at least 8 characters.';
        }
        
        if ($new_password !== $confirm_password) {
            $errors[] = 'The new passwords do not match.';
        }
        
        if (empty($errors)) {
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
            $stmt->execute([$new_hash, $user_id]);
            
            add_audit_log($pdo, $user_id, 'Password Change', 'User updated their account password.');
            set_flash('success', 'Password updated successfully.');
            redirect('profile.php');
        }
    }
}

$page_title = 'My Profile';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page">
    <header class="page-heading">
        <span class="eyebrow">ACCOUNT SETTINGS</span>
        <h1>My Profile</h1>
        <p>Manage your account settings, update your profile picture, and change your password.</p>
    </header>

    <?php if ($errors): ?>
        <div class="error-list" style="margin-bottom: 24px;">
            <?php foreach ($errors as $error): ?>
                <span><?= e($error) ?></span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="profile-grid">
        <!-- Left Column: Profile Card -->
        <div class="profile-card">
            <div class="profile-avatar-container">
                <?php if ($user['profile_picture'] && file_exists(__DIR__ . '/' . $user['profile_picture'])): ?>
                    <img src="<?= e($user['profile_picture']) ?>" alt="Avatar" class="profile-avatar-pic">
                <?php else: ?>
                    <span class="profile-avatar-fallback"><i class="bi bi-person-circle"></i></span>
                <?php endif; ?>
            </div>
            <h2><?= e($user['fullname']) ?></h2>
            <p><?= e($user['username'] ? '@' . $user['username'] : 'No username set') ?></p>
            
            <div class="profile-meta-list">
                <div class="profile-meta-item">
                    <span>Email</span>
                    <strong><?= e($user['email']) ?></strong>
                </div>
                <div class="profile-meta-item">
                    <span>Role</span>
                    <strong><?= e(ucfirst($user['role'])) ?></strong>
                </div>
                <div class="profile-meta-item">
                    <span>Member since</span>
                    <strong><?= e(date('M d, Y', strtotime($user['created_at']))) ?></strong>
                </div>
            </div>
        </div>

        <!-- Right Column: Detail Forms -->
        <div>
            <!-- Personal Information Details Form -->
            <div class="profile-detail-card">
                <h2>Personal Information</h2>
                <p>Update your personal information, address, and profile avatar.</p>

                <form method="post" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_profile">

                    <div class="form-grid">
                        <label>
                            Username
                            <input type="text" name="username" placeholder="e.g. johndoe" value="<?= e($user['username'] ?? '') ?>" pattern="^[a-zA-Z0-9_\-]{3,30}$" title="Username must be 3-30 characters long and can only contain letters, numbers, hyphens, and underscores.">
                        </label>
                        <label>
                            Complete Name
                            <input type="text" name="fullname" required value="<?= e($user['fullname'] ?? '') ?>">
                        </label>
                    </div>

                    <label style="margin-top: 16px;">
                        Complete Address
                        <textarea name="address" required minlength="10"><?= e($user['address'] ?? '') ?></textarea>
                    </label>

                    <label style="margin-top: 16px;">
                        Profile Picture
                        <input type="file" name="profile_picture" class="file-upload-input" accept="image/png, image/jpeg, image/gif, image/webp">
                        <span class="file-upload-help">Allowed formats: PNG, JPG, GIF, WebP. Max file size: 5MB.</span>
                    </label>

                    <button class="button primary" type="submit" style="margin-top: 24px;">Save changes</button>
                </form>
            </div>

            <!-- Password Change Form -->
            <div class="profile-detail-card">
                <h2>Security & Password</h2>
                <p>Change your password. You will need to verify your current password.</p>

                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="change_password">

                    <label>
                        Current Password
                        <input type="password" name="current_password" required minlength="8">
                    </label>

                    <div class="form-grid" style="margin-top: 16px;">
                        <label>
                            New Password
                            <input type="password" name="new_password" required minlength="8">
                        </label>
                        <label>
                            Retype New Password
                            <input type="password" name="confirm_password" required minlength="8">
                        </label>
                    </div>

                    <button class="button primary" type="submit" style="margin-top: 24px;">Update password</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
