# HydraPatch PH

HydraPatch PH is an educational PHP and MySQL storefront plus admin panel created for a second-year BSIT final project. It includes buyer-facing pages, seller/admin tools, secure login, shopping cart and checkout flow, reports, and audit logging.

## Included features

- Buyer pages: home, about, register, login, store, product, cart, checkout, payment
- Admin pages: dashboard, users, inventory, reports, audit log
- Prepared statements for database access
- `password_hash()` and `password_verify()` for authentication
- Session-based login and cart handling
- CSRF token protection for forms
- Program output messages such as `Login Success`, `Record Added`, `Record Updated`, `Record Deleted`, `Search Result`, and `Logout`
- Footer disclaimer shown on every page

## Folder overview

- `admin/` admin dashboard, products, users, and reports
- `assets/` shared CSS and JavaScript
- `config/` database connection
- `database/` MySQL import file
- `includes/` bootstrap, layout, helpers, product visual component
- root `.php` files for buyer pages

## Local setup with XAMPP

1. Copy the `HydraPatch_PH_PHP_MySQL` folder into your XAMPP `htdocs` directory.
2. Start Apache and MySQL in XAMPP Control Panel.
3. Open phpMyAdmin
4. Import `database/HydraPatch_PH.sql`.
5. Visit `http://localhost/HydraPatch_PH_PHP_MySQL/`.

## Database configuration

The current connection file uses:

- Host: `127.0.0.1`
- Port: `3306`
- Database: `hydrapatch_ph`
- Username: `root`
- Password: empty by default

Update `config/database.php` if your local MySQL credentials are different.

## First admin account

Register a normal account from the website first, then promote it in MySQL:

```sql
UPDATE users
SET role = 'admin'
WHERE email = 'your_email@example.com';
```

After that, sign in again and open `admin/dashboard.php`.

## Mail note

Registration uses PHP `mail()` as a classroom demo step. On a normal local XAMPP setup, the message may not actually be sent unless mail is configured. The registration flow still works.

## Security notes

- Passwords are stored with PHP password hashing
- Forms use CSRF protection
- Database writes use prepared statements
- Admin pages require an authenticated admin session

## Suggested demo flow

1. Import the SQL file.
2. Register a customer account.
3. Promote one account to admin in MySQL.
4. Log in as customer and place a sample order.
5. Log in as admin and show dashboard, product updates, user management, reports, and audit logs.

## Team placeholders

The project currently shows sample Team AquaByte members in the About page:

- Aira Santos
- Luis Mendoza
- Mika Reyes
- Paolo Cruz

Replace them with your real group members if needed.
