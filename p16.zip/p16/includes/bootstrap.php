<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

try {
    $pdo->exec("ALTER TABLE orders MODIFY COLUMN order_status ENUM('pending', 'processing', 'packed', 'shipped', 'for_delivery', 'completed', 'cancelled') NOT NULL DEFAULT 'pending'");
} catch (PDOException $e) {
    // Already altered or db not initialized yet
}

try {
    $pdo->exec("ALTER TABLE orders ADD COLUMN customer_archived TINYINT(1) NOT NULL DEFAULT 0");
} catch (PDOException $e) {
    // Already altered or db not initialized yet
}
