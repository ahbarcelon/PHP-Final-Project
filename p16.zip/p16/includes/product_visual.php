<?php
$visual_category = $visual_category ?? 'DAILY';
$visual_tone = $visual_tone ?? 'aqua';
?>
<div class="product-visual tone-<?= e($visual_tone) ?>" aria-label="HydraPatch <?= e($visual_category) ?> concept image">
    <span class="visual-grid"></span>
    <span class="patch-shadow"></span>
    <span class="patch-body"><small>HYDRA</small><b>∿</b><i><?= e(strtoupper($visual_category)) ?></i></span>
    <span class="micro-copy">SMART HYDRATION PATCH</span>
</div>
