<?php
require_once __DIR__ . '/includes/bootstrap.php';

// 1. Save the cart to the database before clearing the session
if (isset($_SESSION['user']) && !empty($_SESSION['cart'])) {
    $cart_json = json_encode($_SESSION['cart']);
    $stmt = $pdo->prepare("REPLACE INTO cart_persistence (user_id, cart_data) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user']['user_id'], $cart_json]);
}

// 2. Log the action
if (is_logged_in()) {
    add_audit_log($pdo, $_SESSION['user']['user_id'], 'Logout', 'User ended the session.');
}

// 3. Clear the user, checkout, AND CART data from the active session
unset($_SESSION['user'], $_SESSION['checkout'], $_SESSION['cart']);

// 4. Regenerate ID and redirect
session_regenerate_id(true);
set_flash('success', 'Logout');
redirect('index.php');