<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login('login.php');

$cart = $_SESSION['cart'] ?? [];
$checkout = $_SESSION['checkout'] ?? null;
if (!$cart || !$checkout) redirect('checkout.php');

$ids = array_map('intval', array_keys($cart));
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$statement = $pdo->prepare("SELECT * FROM products WHERE product_id IN ({$placeholders})");
$statement->execute($ids);
$products = $statement->fetchAll();
$subtotal = 0;
foreach ($products as $product) $subtotal += $product['price'] * $cart[$product['product_id']];
$shipping = 89;
$total = $subtotal + $shipping;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $allowed_methods = ['cash_on_delivery', 'bank_transfer', 'e_wallet'];
    $payment_method = $_POST['payment_method'] ?? '';
    if (!in_array($payment_method, $allowed_methods, true)) {
        set_flash('error', 'Select a valid payment method.');
        redirect('payment.php');
    }

    try {
        $pdo->beginTransaction();
        foreach ($products as $product) {
            $stock_check = $pdo->prepare('SELECT stock_quantity FROM products WHERE product_id = ? FOR UPDATE');
            $stock_check->execute([$product['product_id']]);
            $available = (int) $stock_check->fetchColumn();
            if ($available < $cart[$product['product_id']]) throw new Exception('Not enough stock for ' . $product['product_name']);
        }

        $order_code = order_code();
        $insert_order = $pdo->prepare('INSERT INTO orders (user_id, order_code, total_amount, payment_method, shipping_address, contact_number) VALUES (?, ?, ?, ?, ?, ?)');
        $insert_order->execute([$_SESSION['user']['user_id'], $order_code, $total, $payment_method, $checkout['address'], $checkout['contact']]);
        $order_id = $pdo->lastInsertId();

        $insert_item = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)');
        $update_stock = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ?, status = IF(stock_quantity - ? <= 0, 'out_of_stock', 'available') WHERE product_id = ?");
        foreach ($products as $product) {
            $quantity = $cart[$product['product_id']];
            $insert_item->execute([$order_id, $product['product_id'], $quantity, $product['price'], $product['price'] * $quantity]);
            $update_stock->execute([$quantity, $quantity, $product['product_id']]);
        }

        add_audit_log($pdo, $_SESSION['user']['user_id'], 'Record Added', "Created order {$order_code} using {$payment_method}.");
        $pdo->commit();
        unset($_SESSION['cart'], $_SESSION['checkout']);
        set_flash('success', "Record Added — order {$order_code} confirmed.");
        redirect('index.php');
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('error', $error->getMessage());
        redirect('cart.php');
    }
}

$page_title = 'Payment';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page narrow-page">
    <header class="page-heading"><span class="eyebrow">SECURE CHECKOUT • STEP 2 OF 2</span><h1>Choose how you’ll pay.</h1><p>This project uses mock payment options only. No real payment details are collected.</p></header>
    <div class="cart-layout">
        <form class="panel payment-form" method="post">
            <?= csrf_field() ?>
            <h2>Payment method</h2>
            <label class="payment-option"><input type="radio" name="payment_method" value="cash_on_delivery" checked><b>₱</b><span><strong>Cash on delivery</strong><small>Pay in cash when the order arrives.</small></span></label>
            <label class="payment-option"><input type="radio" name="payment_method" value="bank_transfer"><b>▤</b><span><strong>Bank transfer</strong><small>Use the order reference in your transfer.</small></span></label>
            <label class="payment-option"><input type="radio" name="payment_method" value="e_wallet"><b>◫</b><span><strong>E-wallet placeholder</strong><small>GCash or Maya mock option.</small></span></label>
            <button class="button primary" type="submit">Place order • <?= format_price($total) ?></button>
            <p class="secure-note">▣ No real payment information is processed.</p>
        </form>
        <aside class="order-summary"><span class="eyebrow">FINAL AMOUNT</span><h2>Review total</h2><p><span>Subtotal</span><strong><?= format_price($subtotal) ?></strong></p><p><span>Shipping</span><strong><?= format_price($shipping) ?></strong></p><div><span>Total</span><strong><?= format_price($total) ?></strong></div><small>Delivering to <?= e($checkout['address']) ?></small></aside>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
