<?php
// Update these values if your XAMPP/MySQL setup uses different credentials.
$db_host = 'localhost';
$db_name = 'hydrapatch_ph';
$db_user = 'root';
$db_pass = '';

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $error) {
    exit('Database connection failed. Check config/database.php and confirm that MySQL is running.');
}
