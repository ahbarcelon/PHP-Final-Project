<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

// Handle order/payment status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $order_id = filter_var($_POST['order_id'] ?? 0, FILTER_VALIDATE_INT);
    try {
        if ($action === 'update_order_details' && $order_id) {
            $new_order_status = $_POST['order_status'] ?? '';
            $new_payment_status = $_POST['payment_status'] ?? '';

            $allowed_statuses = ['pending', 'processing', 'packed', 'shipped', 'for_delivery', 'completed', 'cancelled'];
            $allowed_payment = ['pending', 'paid', 'cancelled'];

            if (!in_array($new_order_status, $allowed_statuses, true)) {
                throw new Exception('Invalid order status selected.');
            }
            if (!in_array($new_payment_status, $allowed_payment, true)) {
                throw new Exception('Invalid payment status selected.');
            }

            // Fetch order code for logging
            $stmt = $pdo->prepare('SELECT order_code FROM orders WHERE order_id = ?');
            $stmt->execute([$order_id]);
            $order_code = $stmt->fetchColumn();

            $statement = $pdo->prepare('UPDATE orders SET order_status = ?, payment_status = ? WHERE order_id = ?');
            $statement->execute([$new_order_status, $new_payment_status, $order_id]);

            add_audit_log($pdo, $_SESSION['user']['user_id'], 'updated order details', "Updated status of order {$order_code} to {$new_order_status} and payment to {$new_payment_status}.");
            set_flash('success', 'Record Updated');
        }
    } catch (Throwable $error) {
        set_flash('error', $error->getMessage());
    }
    
    // Redirect keeping search and status query parameters if they exist
    $redirect_url = 'orders.php';
    $params = [];
    if (!empty($_GET['q'])) $params['q'] = $_GET['q'];
    if (!empty($_GET['status'])) $params['status'] = $_GET['status'];
    if (!empty($_GET['id'])) $params['id'] = $_GET['id'];
    if ($params) $redirect_url .= '?' . http_build_query($params);
    redirect($redirect_url);
}

// Fetch selected order details if requested
$selected_order = null;
$selected_order_items = [];
$selected_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if ($selected_id) {
    $stmt = $pdo->prepare("SELECT o.*, u.fullname, u.email FROM orders o JOIN users u ON u.user_id = o.user_id WHERE o.order_id = ?");
    $stmt->execute([$selected_id]);
    $selected_order = $stmt->fetch();
    if ($selected_order) {
        $stmt = $pdo->prepare("SELECT oi.*, p.product_name FROM order_items oi JOIN products p ON p.product_id = oi.product_id WHERE oi.order_id = ?");
        $stmt->execute([$selected_id]);
        $selected_order_items = $stmt->fetchAll();
    }
}

// Search and status filters
$search = trim($_GET['q'] ?? '');
$status_filter = trim($_GET['status'] ?? 'all');

$query = "SELECT o.*, u.fullname, u.email FROM orders o JOIN users u ON u.user_id = o.user_id WHERE 1=1";
$params = [];

if ($search !== '') {
    $query .= " AND (o.order_code LIKE ? OR u.fullname LIKE ? OR u.email LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($status_filter !== 'all') {
    $query .= " AND o.order_status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY o.created_at DESC";
$statement = $pdo->prepare($query);
$statement->execute($params);
$orders = $statement->fetchAll();

$page_title = 'Orders & Tracking';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'orders';
require __DIR__ . '/../includes/admin_header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>

<header class="admin-heading">
    <div>
        <span class="eyebrow">ORDER FULFILLMENT</span>
        <h1>Orders & tracking</h1>
    </div>
    <span class="record-badge">● <?= count($orders) ?> active records</span>
</header>

<!-- Filter Tabs -->
<div class="tabs-row" style="margin-bottom: 24px; display: flex; gap: 8px; flex-wrap: wrap;">
    <?php
    $status_tabs = [
        'all' => 'All Orders',
        'pending' => 'Pending',
        'processing' => 'Processing',
        'packed' => 'Packed',
        'shipped' => 'Shipped',
        'for_delivery' => 'For Delivery',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled'
    ];
    ?>
    <?php foreach ($status_tabs as $val => $label): ?>
        <?php
        $tab_url = 'orders.php?status=' . $val;
        if ($search !== '') $tab_url .= '&q=' . urlencode($search);
        if ($selected_id) $tab_url .= '&id=' . $selected_id;
        $is_active = ($status_filter === $val);
        ?>
        <a href="<?= $tab_url ?>" class="button small <?= $is_active ? 'primary' : 'secondary' ?>" style="text-decoration: none;">
            <?= e($label) ?>
        </a>
    <?php endforeach; ?>
</div>

<div class="manage-grid">
    <!-- Left panel: Detailed View of selected order -->
    <section class="admin-card form-card">
        <?php if ($selected_order): ?>
            <span class="eyebrow">ORDER DETAIL CONTROL</span>
            <h2>Order Details</h2>
            
            <div class="order-details-card" style="padding: 0; box-shadow: none; border: none; background: transparent;">
                <div class="order-details-info">
                    <p><strong>Code:</strong> <?= e($selected_order['order_code']) ?></p>
                    <p><strong>Placed by:</strong> <?= e($selected_order['fullname']) ?> (<a href="users.php?q=<?= urlencode($selected_order['email']) ?>" style="color: var(--primary); text-decoration: none;"><?= e($selected_order['email']) ?></a>)</p>
                    <p><strong>Contact number:</strong> <?= e($selected_order['contact_number']) ?></p>
                    <p><strong>Shipping address:</strong><br><span style="display: block; padding: 10px; background: rgba(0,0,0,0.02); border-radius: var(--radius-sm); margin-top: 4px; border: 1px solid var(--line); font-size: 0.9rem; line-height: 1.4;"><?= e($selected_order['shipping_address']) ?></span></p>
                    <p><strong>Payment details:</strong> <?= e(ucwords(str_replace('_', ' ', $selected_order['payment_method']))) ?></p>
                    <p><strong>Date placed:</strong> <?= e(date('M d, Y g:i A', strtotime($selected_order['created_at']))) ?></p>
                </div>
                
                <!-- Combined status controller with explicit Update Button -->
                <div style="border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); padding: 16px 0; margin-bottom: 16px;">
                    <form method="post" style="display: flex; flex-direction: column; gap: 12px;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_order_details">
                        <input type="hidden" name="order_id" value="<?= (int) $selected_order['order_id'] ?>">
                        
                        <div style="display: flex; flex-direction: column; gap: 4px;">
                            <label style="font-weight: 700; font-size: 0.85rem; color: var(--muted); text-transform: uppercase;">Order Status</label>
                            <select name="order_status" class="admin-select-compact" style="max-width: 100%;">
                                <option value="pending" <?= $selected_order['order_status'] === 'pending' ? 'selected' : '' ?>>Pending / Placed</option>
                                <option value="processing" <?= $selected_order['order_status'] === 'processing' ? 'selected' : '' ?>>Processing</option>
                                <option value="packed" <?= $selected_order['order_status'] === 'packed' ? 'selected' : '' ?>>Packed & Ready to Ship</option>
                                <option value="shipped" <?= $selected_order['order_status'] === 'shipped' ? 'selected' : '' ?>>Shipped Out</option>
                                <option value="for_delivery" <?= $selected_order['order_status'] === 'for_delivery' ? 'selected' : '' ?>>For Delivery</option>
                                <option value="completed" <?= $selected_order['order_status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                                <option value="cancelled" <?= $selected_order['order_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                            </select>
                        </div>

                        <div style="display: flex; flex-direction: column; gap: 4px; margin-top: 6px;">
                            <label style="font-weight: 700; font-size: 0.85rem; color: var(--muted); text-transform: uppercase;">Payment Status</label>
                            <select name="payment_status" class="admin-select-compact" style="max-width: 100%;">
                                <option value="pending" <?= $selected_order['payment_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="paid" <?= $selected_order['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                                <option value="cancelled" <?= $selected_order['payment_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="button primary small" style="margin-top: 8px; width: 100%; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;">
                            <i class="bi bi-check-circle"></i> Update Status
                        </button>
                    </form>
                </div>

                <div class="order-details-items">
                    <h4>Purchased Items</h4>
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <?php foreach ($selected_order_items as $item): ?>
                            <div class="order-item-detail-row">
                                <span><?= e($item['product_name']) ?> <strong style="color: var(--primary);">× <?= (int) $item['quantity'] ?></strong></span>
                                <strong><?= format_price($item['subtotal']) ?></strong>
                            </div>
                        <?php endforeach; ?>
                        <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px solid var(--line); padding-top: 10px; margin-top: 4px;">
                            <span>Total Charge</span>
                            <span style="color: var(--primary);"><?= format_price($selected_order['total_amount']) ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <a class="cancel-link" href="orders.php<?= !empty($_GET['status']) ? '?status=' . urlencode($_GET['status']) : '' ?>" style="margin-top: 20px; display: inline-block;">Clear selection</a>
        <?php else: ?>
            <span class="eyebrow">INSTRUCTIONS</span>
            <h2>Select an Order</h2>
            <div class="access-note" style="margin-top: 16px;">
                <strong>Order fulfillment flow:</strong>
                <p>Select any order from the right table to view recipient contact details, exact shipping address, items list, and to update shipment and payment statuses.</p>
            </div>
        <?php endif; ?>
    </section>

    <!-- Right panel: Listing table -->
    <section class="admin-card table-card">
        <div class="card-title">
            <div>
                <span class="eyebrow">SYSTEM LOG</span>
                <h2>Purchase orders</h2>
            </div>
            <form class="admin-search" method="get">
                <?php if ($status_filter !== 'all'): ?>
                    <input type="hidden" name="status" value="<?= e($status_filter) ?>">
                <?php endif; ?>
                <input name="q" value="<?= e($search) ?>" placeholder="Search order code / client name">
                <button>⌕</button>
            </form>
        </div>

        <div class="table-wrap">
            <table class="compact-table admin-orders-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Payment Status</th>
                        <th>Order Status</th>
                        <th>Date Placed</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$orders): ?>
                        <tr>
                            <td colspan="7">No matching order records found.</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($orders as $order): ?>
                        <?php
                        $is_this_selected = ($selected_id === (int) $order['order_id']);
                        ?>
                        <tr class="<?= $is_this_selected ? 'selected-row' : '' ?>" style="<?= $is_this_selected ? 'background: rgba(139, 224, 197, 0.08); font-weight: bold;' : '' ?>">
                            <td><strong class="order-code-text"><?= e($order['order_code']) ?></strong></td>
                            <td><?= e($order['fullname']) ?></td>
                            <td><?= format_price($order['total_amount']) ?></td>
                            
                            <!-- Payment Status Badge -->
                            <td>
                                <?= badge($order['payment_status'], payment_status_tone($order['payment_status'])) ?>
                            </td>

                            <!-- Order Status Badge -->
                            <td>
                                <?= badge(str_replace('_', ' ', $order['order_status']), order_status_tone($order['order_status'])) ?>
                            </td>

                            <td style="white-space: nowrap;"><?= e(date('M d, Y', strtotime($order['created_at']))) ?></td>
                            <td class="actions-cell">
                                <a class="icon-button" href="orders.php?id=<?= (int) $order['order_id'] ?><?= $search !== '' ? '&q=' . urlencode($search) : '' ?><?= $status_filter !== 'all' ? '&status=' . urlencode($status_filter) : '' ?>" title="View details">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<?php
require __DIR__ . '/../includes/admin_end.php';
require __DIR__ . '/../includes/admin_footer.php';
?>
