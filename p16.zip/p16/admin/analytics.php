<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

// ---- Sales + order volume: last 30 days, zero-filled ----
// A single 30-day dataset is fetched and handed to the client as JSON. The
// two trend charts are drawn in JS from this data so the admin can switch
// between 7D / 14D / 30D (rollup) and click a point to drill into that day,
// without any extra page requests.
$statement = $pdo->prepare(
    "SELECT DATE(created_at) AS d, SUM(total_amount) AS total, COUNT(*) AS c
     FROM orders
     WHERE order_status <> 'cancelled' AND created_at >= (CURDATE() - INTERVAL 29 DAY)
     GROUP BY DATE(created_at)"
);
$statement->execute();
$byDay = [];
foreach ($statement->fetchAll() as $row) {
    $byDay[$row['d']] = ['sales' => (float) $row['total'], 'orders' => (int) $row['c']];
}
$trendSeries = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} day"));
    $sales = round($byDay[$date]['sales'] ?? 0, 2);
    $orders = (int) ($byDay[$date]['orders'] ?? 0);
    $trendSeries[] = [
        'date' => $date,
        'label' => date('M j', strtotime($date)),
        'sales' => $sales,
        'orders' => $orders,
        'aov' => $orders > 0 ? round($sales / $orders, 2) : 0,
    ];
}
$trendTotal = array_sum(array_column($trendSeries, 'sales'));
$orderTrendTotal = array_sum(array_column($trendSeries, 'orders'));

// ---- Order status breakdown ----
$statusRows = $pdo->query('SELECT order_status, COUNT(*) AS c FROM orders GROUP BY order_status ORDER BY c DESC')->fetchAll();
$statusLabels = array_map(fn($r) => ucfirst($r['order_status']), $statusRows);
$statusValues = array_map(fn($r) => (int) $r['c'], $statusRows);
$statusTotal = array_sum($statusValues);

// ---- Revenue by category ----
$categoryRows = $pdo->query(
    "SELECT c.category_name, COALESCE(SUM(oi.subtotal), 0) AS revenue
     FROM categories c
     LEFT JOIN products p ON p.category_id = c.category_id
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY c.category_name
     ORDER BY revenue DESC"
)->fetchAll();
$categoryLabels = array_column($categoryRows, 'category_name');
$categoryValues = array_map(fn($v) => round((float) $v, 2), array_column($categoryRows, 'revenue'));
$categoryMax = $categoryValues ? max($categoryValues) : 0;

// ---- Top products by units sold ----
$topProductRows = $pdo->query(
    "SELECT p.product_name, COALESCE(SUM(oi.quantity), 0) AS units
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY p.product_name
     ORDER BY units DESC
     LIMIT 6"
)->fetchAll();
$productLabels = array_map(fn($n) => str_replace('HydraPatch ', '', $n), array_column($topProductRows, 'product_name'));
$productValues = array_map('intval', array_column($topProductRows, 'units'));
$productMax = $productValues ? max($productValues) : 0;

// ---- Payment method split ----
$paymentRows = $pdo->query('SELECT payment_method, COUNT(*) AS c FROM orders GROUP BY payment_method ORDER BY c DESC')->fetchAll();
$paymentLabels = array_map(fn($r) => ucwords(str_replace('_', ' ', $r['payment_method'])), $paymentRows);
$paymentValues = array_map(fn($r) => (int) $r['c'], $paymentRows);
$paymentTotal = array_sum($paymentValues);

$hasOrders = (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn() > 0;
$palette = chart_palette();

// Local-only helper (kept in this file, not functions.php) that turns a set
// of values into interactive SVG donut segments using stroke-dasharray.
$donutSegments = function (array $values, array $colors, float $r = 60): array {
    $total = array_sum($values);
    $circumference = 2 * M_PI * $r;
    $segments = [];
    $offset = 0.0;
    foreach ($values as $i => $value) {
        $fraction = $total > 0 ? $value / $total : 0;
        $len = $fraction * $circumference;
        $segments[] = [
            'color' => $colors[$i % count($colors)],
            'dasharray' => sprintf('%.3f %.3f', $len, $circumference - $len),
            'dashoffset' => sprintf('%.3f', -$offset),
            'pct' => round($fraction * 100),
        ];
        $offset += $len;
    }
    return $segments;
};

$page_title = 'Analytics';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'analytics';
require __DIR__ . '/../includes/admin_header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">INSIGHTS & TRENDS</span><h1>Analytics</h1></div><a class="button small" href="reports.php">View reports</a></header>

<?php if (!$hasOrders): ?>
<section class="admin-card">
    <div class="chart-empty">
        <div><i class="bi bi-bar-chart" style="font-size:2rem;color:var(--muted);"></i><p style="margin-top:10px;">No order data yet. Charts will populate once orders come in.</p></div>
    </div>
</section>
<?php else: ?>
<div class="analytics-grid">

    <section class="admin-card chart-card wide">
        <div class="card-title">
            <div><span class="eyebrow">SALES TREND</span><h2>Revenue over time</h2></div>
            <div class="chart-controls">
                <div class="range-slicer" role="group" aria-label="Date range">
                    <button type="button" class="range-btn" data-range="7">7D</button>
                    <button type="button" class="range-btn is-active" data-range="14">14D</button>
                    <button type="button" class="range-btn" data-range="30">30D</button>
                </div>
                <small id="salesTotalLabel">Total <?= format_price($trendTotal) ?></small>
            </div>
        </div>
        <svg id="salesChart" class="trend-svg" viewBox="0 0 560 220" preserveAspectRatio="none"></svg>
        <div id="salesAxis" class="trend-axis"></div>
    </section>

    <section class="admin-card chart-card wide">
        <div class="card-title">
            <div><span class="eyebrow">ORDER VOLUME</span><h2>Orders over time</h2></div>
            <small id="ordersTotalLabel">Total <?= $orderTrendTotal ?> orders</small>
        </div>
        <svg id="ordersChart" class="trend-svg" viewBox="0 0 560 220" preserveAspectRatio="none"></svg>
        <div id="ordersAxis" class="trend-axis"></div>
    </section>

    <section id="drilldownPanel" class="admin-card chart-card wide drilldown-panel" hidden>
        <div class="card-title">
            <div><span class="eyebrow">DRILL-DOWN</span><h2 id="drilldownTitle">Day detail</h2></div>
            <button type="button" class="button small drilldown-close-btn" id="drilldownClose">Close</button>
        </div>
        <div class="drilldown-stats">
            <div><span>Revenue</span><strong id="drilldownRevenue">-</strong></div>
            <div><span>Orders</span><strong id="drilldownOrders">-</strong></div>
            <div><span>Avg. order value</span><strong id="drilldownAov">-</strong></div>
        </div>
        <p class="drilldown-hint">Click any point or bar above to drill into that day. Click it again, or Close, to exit.</p>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">ORDER PIPELINE</span><h2>Status breakdown</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut">
                <svg class="donut-svg" viewBox="0 0 150 150">
                    <circle cx="75" cy="75" r="60" fill="none" stroke="#e7edf0" stroke-width="24"></circle>
                    <?php foreach ($donutSegments($statusValues, $palette) as $i => $seg): ?>
                        <circle class="donut-segment" data-index="<?= $i ?>" cx="75" cy="75" r="60" fill="none" stroke="<?= e($seg['color']) ?>" stroke-width="24" stroke-dasharray="<?= $seg['dasharray'] ?>" stroke-dashoffset="<?= $seg['dashoffset'] ?>" transform="rotate(-90 75 75)" data-tip="<?= e(($statusLabels[$i] ?? '') . ' &middot; ' . $statusValues[$i] . ' (' . $seg['pct'] . '%)') ?>"></circle>
                    <?php endforeach; ?>
                </svg>
                <div class="donut-total"><strong><?= $statusTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($statusLabels as $i => $label): ?>
                    <li data-index="<?= $i ?>"><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $statusValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$statusLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">CHECKOUT</span><h2>Payment method split</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut">
                <svg class="donut-svg" viewBox="0 0 150 150">
                    <circle cx="75" cy="75" r="60" fill="none" stroke="#e7edf0" stroke-width="24"></circle>
                    <?php foreach ($donutSegments($paymentValues, $palette) as $i => $seg): ?>
                        <circle class="donut-segment" data-index="<?= $i ?>" cx="75" cy="75" r="60" fill="none" stroke="<?= e($seg['color']) ?>" stroke-width="24" stroke-dasharray="<?= $seg['dasharray'] ?>" stroke-dashoffset="<?= $seg['dashoffset'] ?>" transform="rotate(-90 75 75)" data-tip="<?= e(($paymentLabels[$i] ?? '') . ' &middot; ' . $paymentValues[$i] . ' (' . $seg['pct'] . '%)') ?>"></circle>
                    <?php endforeach; ?>
                </svg>
                <div class="donut-total"><strong><?= $paymentTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($paymentLabels as $i => $label): ?>
                    <li data-index="<?= $i ?>"><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $paymentValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$paymentLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">REVENUE MIX</span><h2>By category</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($categoryLabels as $i => $label): $pct = $categoryMax > 0 ? round(($categoryValues[$i] / $categoryMax) * 100) : 0; ?>
                <div class="metric-bar-row" data-tip="<?= e($label . ' &middot; ' . format_price($categoryValues[$i]) . ' (' . $pct . '%)') ?>"><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= format_price($categoryValues[$i]) ?></strong></div>
            <?php endforeach; ?>
            <?php if (!$categoryLabels): ?><p>No category data yet.</p><?php endif; ?>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">BEST SELLERS</span><h2>Top products by units sold</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($productLabels as $i => $label): $pct = $productMax > 0 ? round(($productValues[$i] / $productMax) * 100) : 0; ?>
                <div class="metric-bar-row" data-tip="<?= e($label . ' &middot; ' . $productValues[$i] . ' units (' . $pct . '%)') ?>"><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= $productValues[$i] ?> units</strong></div>
            <?php endforeach; ?>
            <?php if (!$productLabels): ?><p>No sales data yet.</p><?php endif; ?>
        </div>
    </section>

</div>
<div id="chartTooltip" class="chart-tooltip" role="tooltip" hidden></div>
<script>
(function () {
    var SERIES = <?= json_encode($trendSeries, JSON_UNESCAPED_SLASHES) ?>;
    var currency = function (n) {
        return '\u20B1' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };

    // ---- Rollup: 7D/14D show daily points; 30D groups into ~3-day buckets
    // so the chart stays readable instead of cramming 30 points in. ----
    function sliceRange(days) {
        var slice = SERIES.slice(SERIES.length - days);
        if (days <= 14) return slice;
        var bucketSize = 3;
        var buckets = [];
        for (var i = 0; i < slice.length; i += bucketSize) {
            var chunk = slice.slice(i, i + bucketSize);
            var sales = chunk.reduce(function (s, d) { return s + d.sales; }, 0);
            var orders = chunk.reduce(function (s, d) { return s + d.orders; }, 0);
            buckets.push({
                date: chunk[0].date,
                label: chunk.length > 1 ? (chunk[0].label + '\u2013' + chunk[chunk.length - 1].label) : chunk[0].label,
                sales: Math.round(sales * 100) / 100,
                orders: orders,
                aov: orders > 0 ? Math.round((sales / orders) * 100) / 100 : 0,
                days: chunk.map(function (d) { return d.date; })
            });
        }
        return buckets;
    }

    var W = 560, H = 220, PAD = 20;
    var GRID_STEPS = 4;
    var svgNS = 'http://www.w3.org/2000/svg';

    function el(tag, attrs) {
        var n = document.createElementNS(svgNS, tag);
        for (var k in attrs) n.setAttribute(k, attrs[k]);
        return n;
    }

    function gridlines(svg) {
        for (var g = 0; g <= GRID_STEPS; g++) {
            var y = PAD + (g / GRID_STEPS) * (H - PAD * 2);
            svg.appendChild(el('line', { class: 'chart-gridline', x1: PAD, y1: y, x2: W - 10, y2: y }));
        }
    }

    function renderLine(svg, points, key, formatValue) {
        svg.innerHTML = '';
        gridlines(svg);
        var max = Math.max(1, Math.max.apply(null, points.map(function (p) { return p[key]; })));
        var count = points.length;
        var stepX = (W - PAD * 2) / Math.max(1, count - 1);
        var coords = points.map(function (p, i) {
            var x = PAD + stepX * i;
            var y = H - PAD - (p[key] / max) * (H - PAD * 2);
            return [x, y];
        });
        if (count === 1) coords[0][0] = W / 2;

        var areaPts = coords.map(function (c) { return c[0] + ',' + c[1]; }).join(' ');
        areaPts = (PAD) + ',' + (H - PAD) + ' ' + areaPts + ' ' + (coords[coords.length - 1][0]) + ',' + (H - PAD);
        svg.appendChild(el('polygon', { points: areaPts, fill: 'rgba(15, 109, 141, 0.12)' }));
        svg.appendChild(el('polyline', { points: coords.map(function (c) { return c.join(','); }).join(' '), fill: 'none', stroke: '#0f6d8d', 'stroke-width': 3, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));

        points.forEach(function (p, i) {
            var c = coords[i];
            var hit = el('circle', { class: 'chart-point', cx: c[0], cy: c[1], r: 11, fill: 'transparent', 'data-tip': p.label + ' &middot; ' + formatValue(p[key]), 'data-drill': i });
            var dot = el('circle', { class: 'chart-point-dot', cx: c[0], cy: c[1], r: 3.5, fill: '#0f6d8d' });
            svg.appendChild(hit);
            svg.appendChild(dot);
        });
    }

    function renderBars(svg, points, key, formatValue) {
        svg.innerHTML = '';
        gridlines(svg);
        var max = Math.max(1, Math.max.apply(null, points.map(function (p) { return p[key]; })));
        var count = points.length;
        var slot = (W - PAD * 2) / Math.max(1, count);
        var barWidth = Math.max(6, slot * 0.55);
        points.forEach(function (p, i) {
            var x = PAD + slot * i + (slot - barWidth) / 2;
            var h = (p[key] / max) * (H - PAD * 2);
            var y = H - PAD - h;
            svg.appendChild(el('rect', { class: 'chart-bar', x: x, y: y, width: barWidth, height: h, rx: 3, fill: '#8be0c5', 'data-tip': p.label + ' &middot; ' + formatValue(p[key]), 'data-drill': i }));
        });
    }

    function renderAxis(container, points) {
        container.innerHTML = '';
        var picks = points.length === 1 ? [0] : [0, Math.floor((points.length - 1) / 2), points.length - 1];
        picks.forEach(function (i) {
            var span = document.createElement('span');
            span.textContent = points[i].label;
            container.appendChild(span);
        });
    }

    var salesChart = document.getElementById('salesChart');
    var ordersChart = document.getElementById('ordersChart');
    var salesAxis = document.getElementById('salesAxis');
    var ordersAxis = document.getElementById('ordersAxis');
    var salesTotalLabel = document.getElementById('salesTotalLabel');
    var ordersTotalLabel = document.getElementById('ordersTotalLabel');
    var currentPoints = [];

    function draw(days) {
        currentPoints = sliceRange(days);
        renderLine(salesChart, currentPoints, 'sales', currency);
        renderBars(ordersChart, currentPoints, 'orders', function (n) { return n + (n === 1 ? ' order' : ' orders'); });
        renderAxis(salesAxis, currentPoints);
        renderAxis(ordersAxis, currentPoints);
        var salesTotal = currentPoints.reduce(function (s, p) { return s + p.sales; }, 0);
        var ordersTotal = currentPoints.reduce(function (s, p) { return s + p.orders; }, 0);
        salesTotalLabel.textContent = 'Total ' + currency(salesTotal);
        ordersTotalLabel.textContent = 'Total ' + ordersTotal + ' orders';
        closeDrilldown();
    }

    document.querySelectorAll('.range-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.range-btn').forEach(function (b) { b.classList.remove('is-active'); });
            btn.classList.add('is-active');
            draw(parseInt(btn.getAttribute('data-range'), 10));
        });
    });

    // ---- Drill-down: click a point/bar to see that day's (or bucket's) detail ----
    var panel = document.getElementById('drilldownPanel');
    var drilldownTitle = document.getElementById('drilldownTitle');
    var drilldownRevenue = document.getElementById('drilldownRevenue');
    var drilldownOrders = document.getElementById('drilldownOrders');
    var drilldownAov = document.getElementById('drilldownAov');
    var activeDrillIndex = null;

    function openDrilldown(index) {
        var p = currentPoints[index];
        if (!p) return;
        activeDrillIndex = index;
        drilldownTitle.textContent = p.label;
        drilldownRevenue.textContent = currency(p.sales);
        drilldownOrders.textContent = p.orders;
        drilldownAov.textContent = p.aov ? currency(p.aov) : '\u2014';
        panel.hidden = false;
        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function closeDrilldown() {
        activeDrillIndex = null;
        panel.hidden = true;
    }

    document.getElementById('drilldownClose').addEventListener('click', closeDrilldown);

    [salesChart, ordersChart].forEach(function (svg) {
        svg.addEventListener('click', function (evt) {
            var target = evt.target.closest('[data-drill]');
            if (!target) return;
            var index = parseInt(target.getAttribute('data-drill'), 10);
            if (activeDrillIndex === index) { closeDrilldown(); return; }
            openDrilldown(index);
        });
    });

    draw(14);

    // ---- Shared tooltip, delegated so it keeps working after re-render ----
    var tip = document.getElementById('chartTooltip');

    function showTip(target, evt) {
        var text = target.getAttribute('data-tip');
        if (!text) return;
        tip.innerHTML = text;
        tip.hidden = false;
        moveTip(evt);
        var index = target.getAttribute('data-index');
        if (index !== null) {
            document.querySelectorAll('[data-index="' + index + '"]').forEach(function (n) { n.classList.add('is-active'); });
        } else {
            target.classList.add('is-active');
        }
    }

    function moveTip(evt) {
        if (!evt || typeof evt.clientX !== 'number') return;
        var x = evt.clientX + 14, y = evt.clientY + 14;
        var maxX = window.innerWidth - tip.offsetWidth - 12;
        var maxY = window.innerHeight - tip.offsetHeight - 12;
        tip.style.left = Math.min(x, Math.max(12, maxX)) + 'px';
        tip.style.top = Math.min(y, Math.max(12, maxY)) + 'px';
    }

    function hideTip() {
        tip.hidden = true;
        document.querySelectorAll('.is-active').forEach(function (n) { n.classList.remove('is-active'); });
    }

    document.addEventListener('mouseover', function (evt) {
        var target = evt.target.closest('[data-tip]');
        if (target) showTip(target, evt);
    });
    document.addEventListener('mousemove', function (evt) {
        if (!tip.hidden) moveTip(evt);
    });
    document.addEventListener('mouseout', function (evt) {
        var target = evt.target.closest('[data-tip]');
        if (target) hideTip();
    });

    document.querySelectorAll('.chart-legend-list li[data-index]').forEach(function (li) {
        li.addEventListener('mouseenter', function () {
            var index = li.getAttribute('data-index');
            document.querySelectorAll('[data-index="' + index + '"]').forEach(function (n) { n.classList.add('is-active'); });
        });
        li.addEventListener('mouseleave', hideTip);
    });
})();
</script>
<?php endif; ?>

<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/admin_footer.php'; ?>
