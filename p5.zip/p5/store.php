<?php
require_once __DIR__ . '/includes/bootstrap.php';

$search = trim($_GET['q'] ?? '');
$category = (int) ($_GET['category'] ?? 0);
$conditions = [];
$parameters = [];

if ($search !== '') {
    $conditions[] = '(p.product_name LIKE ? OR p.description LIKE ?)';
    $parameters[] = '%' . $search . '%';
    $parameters[] = '%' . $search . '%';
}
if ($category > 0) {
    $conditions[] = 'p.category_id = ?';
    $parameters[] = $category;
}

$sql = 'SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id';
if ($conditions) $sql .= ' WHERE ' . implode(' AND ', $conditions);
$sql .= ' ORDER BY p.product_id';
$statement = $pdo->prepare($sql);
$statement->execute($parameters);
$products = $statement->fetchAll();
$categories = $pdo->query('SELECT * FROM categories ORDER BY category_id')->fetchAll();
$tones = ['aqua', 'violet', 'lime', 'blue', 'coral'];
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];

$page_title = 'Shop';
$active_page = 'store';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page store-page">
    <header class="store-hero"><div><span class="eyebrow">THE HYDRAPATCH COLLECTION</span><h1>Made for every kind of day.</h1><p>Five purpose-built concepts. One simple reminder: take care of yourself.</p></div><b>05 <small>PATCH<br>FORMULAS</small></b></header>
    <div class="store-tools">
        <nav class="filters"><a class="<?= $category === 0 ? 'active' : '' ?>" href="store.php">All</a><?php foreach ($categories as $item): ?><a class="<?= $category === (int) $item['category_id'] ? 'active' : '' ?>" href="store.php?category=<?= (int) $item['category_id'] ?>"><?= e($item['category_name']) ?></a><?php endforeach; ?></nav>
        <form class="search-form" method="get"><label class="sr-only" for="q">Search products</label><input id="q" name="q" value="<?= e($search) ?>" placeholder="Search collection"><button>⌕</button></form>
    </div>
    <?php if ($search !== ''): ?><div class="search-result">Search Result: <?= count($products) ?> record(s) found for “<?= e($search) ?>”</div><?php endif; ?>
    <div class="record-line"><span><?= count($products) ?> products</span><span>Stocks synced with MySQL inventory</span></div>
    <div class="product-grid store-grid">
        <?php foreach ($products as $index => $product): ?>
            <article class="product-card">
                <?php
                    $visual_tone = $tones[((int) $product['category_id'] - 1) % 5];
                    $image_key = strtolower(str_replace(' ', '', $product['category_name']));
                    $image_file = $category_images[$image_key] ?? null;
                ?>
                <div class="product-visual tone-<?= e($visual_tone) ?>">
                    <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="<?= e($product['product_name']) ?>"><?php endif; ?>
                </div>
                <div class="product-info"><small><?= e(strtoupper($product['category_name'])) ?> • <?= (int) $product['stock_quantity'] ?> IN STOCK</small><h3><a href="product.php?id=<?= (int) $product['product_id'] ?>"><?= e($product['product_name']) ?></a></h3><p><?= e($product['description']) ?></p><div><span><strong><?= format_price($product['price']) ?></strong><small><?= $product['status'] === 'available' ? 'Available' : 'Out of stock' ?></small></span><form method="post" action="cart.php"><?= csrf_field() ?><input type="hidden" name="action" value="add"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button class="round-button" <?= $product['status'] !== 'available' ? 'disabled' : '' ?>>＋</button></form></div></div>
            </article>
        <?php endforeach; ?>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>