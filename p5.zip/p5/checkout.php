<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login('login.php');

$cart = $_SESSION['cart'] ?? [];
if (!$cart) {
    set_flash('error', 'Your cart is empty.');
    redirect('store.php');
}

$ids = array_map('intval', array_keys($cart));
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$statement = $pdo->prepare("SELECT * FROM products WHERE product_id IN ({$placeholders})");
$statement->execute($ids);
$products = $statement->fetchAll();
$subtotal = 0;
foreach ($products as $product) $subtotal += $product['price'] * $cart[$product['product_id']];
$shipping = 89;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fullname = trim($_POST['fullname'] ?? '');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $address = trim($_POST['shipping_address'] ?? '');
    $contact = preg_replace('/[^0-9+ ]/', '', $_POST['contact_number'] ?? '');
    if (strlen($fullname) >= 3 && $email && strlen($address) >= 10 && strlen($contact) >= 10) {
        $_SESSION['checkout'] = compact('fullname', 'email', 'address', 'contact');
        redirect('payment.php');
    }
    set_flash('error', 'Please complete all shipping fields correctly.');
    redirect('checkout.php');
}

$page_title = 'Checkout';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page narrow-page">
    <header class="page-heading"><span class="eyebrow">SECURE CHECKOUT • STEP 1 OF 2</span><h1>Where should we send it?</h1><p>Confirm your customer and delivery details before selecting a mock payment method.</p></header>
    <div class="cart-layout">
        <form class="panel checkout-form" method="post">
            <?= csrf_field() ?>
            <h2>Customer details</h2>
            <div class="form-grid"><label>Complete name<input name="fullname" required value="<?= e($_SESSION['user']['fullname']) ?>"></label><label>Email address<input name="email" type="email" required value="<?= e($_SESSION['user']['email']) ?>"></label></div>
            <label>Complete shipping address<textarea name="shipping_address" required></textarea></label>
            <div class="form-grid"><label>Contact number<input name="contact_number" required pattern="[0-9+ ]{10,18}"></label><label>Delivery note<input name="delivery_note" placeholder="Optional landmark"></label></div>
            <button class="button primary" type="submit">Continue to payment →</button>
        </form>
        <aside class="order-summary"><span class="eyebrow">ORDER SUMMARY</span><h2>Your order</h2><p><span><?= cart_count() ?> patch pack(s)</span><strong><?= format_price($subtotal) ?></strong></p><p><span>Shipping</span><strong><?= format_price($shipping) ?></strong></p><div><span>Total</span><strong><?= format_price($subtotal + $shipping) ?></strong></div><small>▣ Secure classroom-demo checkout</small></aside>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
