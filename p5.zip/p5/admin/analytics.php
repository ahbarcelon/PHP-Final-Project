<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

// ---- Sales trend: last 14 days, zero-filled ----
$statement = $pdo->prepare(
    "SELECT DATE(created_at) AS d, SUM(total_amount) AS total
     FROM orders
     WHERE order_status <> 'cancelled' AND created_at >= (CURDATE() - INTERVAL 13 DAY)
     GROUP BY DATE(created_at)"
);
$statement->execute();
$salesByDay = [];
foreach ($statement->fetchAll() as $row) {
    $salesByDay[$row['d']] = (float) $row['total'];
}
$trendLabels = [];
$trendValues = [];
for ($i = 13; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} day"));
    $trendLabels[] = date('M d', strtotime($date));
    $trendValues[] = round($salesByDay[$date] ?? 0, 2);
}
$trendTotal = array_sum($trendValues);
$spark = sparkline_points($trendValues, 560, 200, 14);

// ---- Order status breakdown ----
$statusRows = $pdo->query('SELECT order_status, COUNT(*) AS c FROM orders GROUP BY order_status ORDER BY c DESC')->fetchAll();
$statusLabels = array_map(fn($r) => ucfirst($r['order_status']), $statusRows);
$statusValues = array_map(fn($r) => (int) $r['c'], $statusRows);
$statusTotal = array_sum($statusValues);

// ---- Revenue by category ----
$categoryRows = $pdo->query(
    "SELECT c.category_name, COALESCE(SUM(oi.subtotal), 0) AS revenue
     FROM categories c
     LEFT JOIN products p ON p.category_id = c.category_id
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY c.category_name
     ORDER BY revenue DESC"
)->fetchAll();
$categoryLabels = array_column($categoryRows, 'category_name');
$categoryValues = array_map(fn($v) => round((float) $v, 2), array_column($categoryRows, 'revenue'));
$categoryMax = $categoryValues ? max($categoryValues) : 0;

// ---- Top products by units sold ----
$topProductRows = $pdo->query(
    "SELECT p.product_name, COALESCE(SUM(oi.quantity), 0) AS units
     FROM products p
     LEFT JOIN order_items oi ON oi.product_id = p.product_id
     LEFT JOIN orders o ON o.order_id = oi.order_id AND o.order_status <> 'cancelled'
     GROUP BY p.product_name
     ORDER BY units DESC
     LIMIT 6"
)->fetchAll();
$productLabels = array_map(fn($n) => str_replace('HydraPatch ', '', $n), array_column($topProductRows, 'product_name'));
$productValues = array_map('intval', array_column($topProductRows, 'units'));
$productMax = $productValues ? max($productValues) : 0;

// ---- Payment method split ----
$paymentRows = $pdo->query('SELECT payment_method, COUNT(*) AS c FROM orders GROUP BY payment_method ORDER BY c DESC')->fetchAll();
$paymentLabels = array_map(fn($r) => ucwords(str_replace('_', ' ', $r['payment_method'])), $paymentRows);
$paymentValues = array_map(fn($r) => (int) $r['c'], $paymentRows);
$paymentTotal = array_sum($paymentValues);

$hasOrders = (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn() > 0;
$palette = chart_palette();

$page_title = 'Analytics';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'analytics';
require __DIR__ . '/../includes/admin_header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">INSIGHTS & TRENDS</span><h1>Analytics</h1></div><a class="button small" href="reports.php">View reports</a></header>

<?php if (!$hasOrders): ?>
<section class="admin-card">
    <div class="chart-empty">
        <div><i class="bi bi-bar-chart" style="font-size:2rem;color:var(--muted);"></i><p style="margin-top:10px;">No order data yet. Charts will populate once orders come in.</p></div>
    </div>
</section>
<?php else: ?>
<div class="analytics-grid">

    <section class="admin-card chart-card wide">
        <div class="card-title"><div><span class="eyebrow">SALES TREND</span><h2>Last 14 days</h2></div><small>Total <?= format_price($trendTotal) ?></small></div>
        <svg class="trend-svg" viewBox="0 0 <?= $spark['width'] ?> <?= $spark['height'] ?>" preserveAspectRatio="none">
            <?php if ($spark['area'] !== ''): ?>
                <polygon points="<?= e($spark['area']) ?>" fill="rgba(15, 109, 141, 0.14)"></polygon>
                <polyline points="<?= e($spark['line']) ?>" fill="none" stroke="#0f6d8d" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></polyline>
                <?php foreach ($spark['points'] as $point): ?>
                    <circle cx="<?= $point[0] ?>" cy="<?= $point[1] ?>" r="3.5" fill="#0f6d8d"></circle>
                <?php endforeach; ?>
            <?php endif; ?>
        </svg>
        <div class="trend-axis"><span><?= e($trendLabels[0] ?? '') ?></span><span><?= e($trendLabels[intdiv(count($trendLabels), 2)] ?? '') ?></span><span><?= e($trendLabels[count($trendLabels) - 1] ?? '') ?></span></div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">ORDER PIPELINE</span><h2>Status breakdown</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut" style="background: <?= e(donut_gradient($statusValues, $palette)) ?>;">
                <div class="donut-total"><strong><?= $statusTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($statusLabels as $i => $label): ?>
                    <li><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $statusValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$statusLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">CHECKOUT</span><h2>Payment method split</h2></div></div>
        <div class="donut-chart-wrap">
            <div class="donut" style="background: <?= e(donut_gradient($paymentValues, $palette)) ?>;">
                <div class="donut-total"><strong><?= $paymentTotal ?></strong><small>Orders</small></div>
            </div>
            <ul class="chart-legend-list">
                <?php foreach ($paymentLabels as $i => $label): ?>
                    <li><i style="background: <?= e($palette[$i % count($palette)]) ?>"></i><?= e($label) ?><b><?= $paymentValues[$i] ?></b></li>
                <?php endforeach; ?>
                <?php if (!$paymentLabels): ?><li>No orders yet</li><?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">REVENUE MIX</span><h2>By category</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($categoryLabels as $i => $label): $pct = $categoryMax > 0 ? round(($categoryValues[$i] / $categoryMax) * 100) : 0; ?>
                <div><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= format_price($categoryValues[$i]) ?></strong></div>
            <?php endforeach; ?>
            <?php if (!$categoryLabels): ?><p>No category data yet.</p><?php endif; ?>
        </div>
    </section>

    <section class="admin-card chart-card">
        <div class="card-title"><div><span class="eyebrow">BEST SELLERS</span><h2>Top products by units sold</h2></div></div>
        <div class="metric-bar-list">
            <?php foreach ($productLabels as $i => $label): $pct = $productMax > 0 ? round(($productValues[$i] / $productMax) * 100) : 0; ?>
                <div><span><?= e($label) ?></span><i><b style="width: <?= $pct ?>%; background: <?= e($palette[$i % count($palette)]) ?>"></b></i><strong><?= $productValues[$i] ?> units</strong></div>
            <?php endforeach; ?>
            <?php if (!$productLabels): ?><p>No sales data yet.</p><?php endif; ?>
        </div>
    </section>

</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/admin_footer.php'; ?>
