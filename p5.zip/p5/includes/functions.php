<?php
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . $path);
    exit;
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash()
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function old($key, $default = '')
{
    return e($_POST[$key] ?? $default);
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e($_SESSION['csrf_token']) . '">';
}

function verify_csrf()
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $submitted)) {
        http_response_code(419);
        exit('Invalid form request. Please return to the previous page and try again.');
    }
}

function is_logged_in()
{
    return !empty($_SESSION['user']);
}

function is_admin()
{
    return isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin';
}

function require_login($login_path = 'login.php')
{
    if (!is_logged_in()) {
        set_flash('error', 'Please sign in before continuing.');
        redirect($login_path);
    }
}

function require_admin($login_path = '../login.php')
{
    if (!is_admin()) {
        set_flash('error', 'Administrator access is required.');
        redirect($login_path);
    }
}

function cart_count()
{
    return array_sum($_SESSION['cart'] ?? []);
}

function add_audit_log($pdo, $user_id, $action, $details = '')
{
    $statement = $pdo->prepare(
        'INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)'
    );
    $statement->execute([$user_id, $action, $details]);
}

function format_price($amount)
{
    return '₱' . number_format((float) $amount, 2);
}

function order_code()
{
    return 'HP-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
}

function redirect_back($default = 'store.php')
{
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    if ($referer !== '' && parse_url($referer, PHP_URL_HOST) === ($_SERVER['HTTP_HOST'] ?? '')) {
        redirect($referer);
    }
    redirect($default);
}

/**
 * Badge color mapping. Each helper returns a small "tone" keyword
 * (green / orange / red / blue / gray / purple / cyan) which maps to a
 * `.badge-<tone>` class defined once in assets/css/style.css. Anything
 * unrecognised safely falls back to gray instead of breaking the page.
 */
function badge_tone(string $value, array $map, string $default = 'gray'): string
{
    $value = strtolower(trim($value));
    foreach ($map as $needle => $tone) {
        if (str_contains($value, $needle)) {
            return $tone;
        }
    }
    return $default;
}

function order_status_tone($status)
{
    return badge_tone((string) $status, [
        'complete' => 'green',
        'deliver'  => 'green',
        'pending'  => 'orange',
        'process'  => 'blue',
        'shipped'  => 'blue',
        'reject'   => 'red',
        'cancel'   => 'red',
        'fail'     => 'red',
    ]);
}

function payment_status_tone($status)
{
    return badge_tone((string) $status, [
        'paid'    => 'green',
        'pending' => 'orange',
        'cancel'  => 'red',
        'fail'    => 'red',
        'refund'  => 'purple',
    ]);
}

function product_status_tone($status)
{
    return badge_tone((string) $status, [
        'available'    => 'green',
        'out_of_stock' => 'red',
        'out of stock' => 'red',
        'low'          => 'orange',
    ]);
}

function user_status_tone($isActive)
{
    return $isActive ? 'green' : 'gray';
}

function role_tone($role)
{
    return badge_tone((string) $role, [
        'admin'    => 'red',
        'manager'  => 'blue',
        'employee' => 'green',
        'customer' => 'gray',
    ]);
}

function action_tone($action)
{
    return badge_tone((string) $action, [
        'add'     => 'green',
        'creat'   => 'green',
        'edit'    => 'blue',
        'updat'   => 'blue',
        'role'    => 'blue',
        'chang'   => 'blue',
        'delet'   => 'red',
        'remov'   => 'red',
        'login'   => 'purple',
        'logout'  => 'gray',
        'view'    => 'cyan',
        'access'  => 'cyan',
    ]);
}

function badge($label, string $tone, string $icon = '')
{
    $iconHtml = $icon !== '' ? '<i class="bi ' . e($icon) . '"></i> ' : '';
    return '<span class="badge badge-' . e($tone) . '">' . $iconHtml . e($label) . '</span>';
}

/**
 * Self-contained (no external JS) chart helpers used by admin/analytics.php.
 * Charts render as CSS conic-gradient donuts and inline SVG so they never
 * depend on a CDN being reachable.
 */
function chart_palette(): array
{
    return ['#0f6d8d', '#8be0c5', '#e1a53f', '#bf4f5d', '#6a3a9b', '#14adc7', '#4c5b64'];
}

function donut_gradient(array $values, array $colors): string
{
    $total = array_sum($values);
    if ($total <= 0) {
        return 'conic-gradient(#e7edf0 0deg 360deg)';
    }
    $stops = [];
    $start = 0.0;
    foreach ($values as $i => $value) {
        $slice = ($value / $total) * 360;
        $end = $start + $slice;
        $color = $colors[$i % count($colors)];
        $stops[] = sprintf('%s %.2fdeg %.2fdeg', $color, $start, $end);
        $start = $end;
    }
    return 'conic-gradient(' . implode(', ', $stops) . ')';
}

function sparkline_points(array $values, int $width = 560, int $height = 200, int $padding = 14): array
{
    $count = count($values);
    if ($count === 0) {
        return ['line' => '', 'area' => '', 'width' => $width, 'height' => $height];
    }
    $max = max(1, max($values));
    $stepX = $count > 1 ? ($width - $padding * 2) / ($count - 1) : 0;
    $points = [];
    foreach (array_values($values) as $i => $v) {
        $x = $padding + $stepX * $i;
        $y = $height - $padding - (($v / $max) * ($height - $padding * 2));
        $points[] = [round($x, 1), round($y, 1)];
    }
    $line = implode(' ', array_map(fn($p) => $p[0] . ',' . $p[1], $points));
    $lastX = $points[count($points) - 1][0];
    $area = "{$padding},{$height} {$line} {$lastX},{$height}";
    return ['line' => $line, 'area' => $area, 'points' => $points, 'width' => $width, 'height' => $height];
}