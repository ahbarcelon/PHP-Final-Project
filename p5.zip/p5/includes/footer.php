</main>
<footer class="site-footer">
    <div class="footer-grid shell">
        <div>
            <span class="brand footer-brand"><span class="logo-mark"><i></i><b>⌁</b></span><span><strong>HydraPatch</strong><small>PH • TEAM AQUABYTE</small></span></span>
            <p>Smart hydration awareness for everyday Filipino life—an educational health-tech commerce concept.</p>
        </div>
        <div><strong>EXPLORE</strong><a href="<?= e($base_path) ?>store.php">Shop all</a><a href="<?= e($base_path) ?>about.php">Our story</a><a href="<?= e($base_path) ?>register.php">Register</a></div>
        <div><strong>PROJECT</strong><span>Team AquaByte</span><span>BSIT • Year 2</span><span>Final project 2026</span></div>
    </div>
    <div class="disclaimer">“Disclaimer: This website is for educational purposes only and is a requirement for our final project.”</div>
</footer>
<script src="<?= e($base_path) ?>assets/js/app.js"></script>
</body>
</html>
