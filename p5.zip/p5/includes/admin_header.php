<?php
$page_title = $page_title ?? 'Admin';
$base_path = $base_path ?? '';
$flash = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
    <script>
        (function() {
            const savedTheme = localStorage.getItem('theme');
            const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            const theme = savedTheme || (systemPrefersDark ? 'dark' : 'light');
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="HydraPatch PH admin panel">
    <title><?= e($page_title) ?> | HydraPatch PH Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Sora:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= e($base_path) ?>assets/css/style.css">
</head>
<body class="admin-body">
<header class="admin-topbar">
    <a class="admin-topbar-brand" href="dashboard.php"><i class="bi bi-droplet-half"></i> HydraPatch <span>Admin</span></a>
    <button id="theme-toggle" class="theme-toggle-btn" aria-label="Toggle dark/light theme" title="Toggle dark/light theme">
        <i class="bi bi-moon-stars-fill"></i>
        <i class="bi bi-sun-fill"></i>
    </button>
    <a class="admin-topbar-back" href="<?= e($base_path) ?>index.php"><i class="bi bi-box-arrow-left"></i> Back to store</a>
</header>
<?php if ($flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?> shell-wide" role="status"><b>✓</b><?= e($flash['message']) ?></div>
<?php endif; ?>
<main>
