<?php
require_once __DIR__ . '/includes/bootstrap.php';
$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$statement = $pdo->prepare('SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id WHERE p.product_id = ?');
$statement->execute([$product_id]);
$product = $statement->fetch();
if (!$product) {
    http_response_code(404);
    set_flash('error', 'Product record not found.');
    redirect('store.php');
}
$tones = ['aqua', 'violet', 'lime', 'blue', 'coral'];
$page_title = $product['product_name'];
$active_page = 'store';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page product-detail">
    <a class="back-link" href="store.php">← Back to collection</a>
    <div class="product-detail-grid">
        <?php $visual_category = $product['category_name']; $visual_tone = $tones[((int) $product['category_id'] - 1) % 5]; require __DIR__ . '/includes/product_visual.php'; ?>
        <div><span class="eyebrow">HYDRAPATCH ORIGINAL</span><h1><?= e($product['product_name']) ?></h1><p class="category-line">Made for <?= e(strtolower($product['category_name'])) ?> routines</p><div class="rating">★★★★★ <span>4.9 • 128 concept reviews</span></div><p><?= e($product['description']) ?> A sleek format that turns a visual cue into a more mindful hydration routine.</p><div class="detail-specs"><span>✓ Lightweight & flexible</span><span>✓ 8-hour wear concept</span><span>✓ Beginner-friendly</span><span>✓ Individually packed</span></div><strong class="detail-price"><?= format_price($product['price']) ?></strong><span class="stock-status"><?= (int) $product['stock_quantity'] ?> in stock</span><form method="post" action="cart.php"><?= csrf_field() ?><input type="hidden" name="action" value="add"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button class="button primary wide" <?= $product['status'] !== 'available' ? 'disabled' : '' ?>>Add to cart ＋</button></form><small class="fine-print">Educational product concept only. No medical claims are made.</small></div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
