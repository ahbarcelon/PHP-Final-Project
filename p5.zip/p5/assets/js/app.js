const siteHeader = document.querySelector(".site-header");
const menuToggle = document.querySelector(".menu-toggle");
const flashMessage = document.querySelector(".flash");

if (siteHeader && menuToggle) {
    menuToggle.addEventListener("click", () => {
        const expanded = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", String(!expanded));
        siteHeader.classList.toggle("menu-open", !expanded);
    });
}

const sidebarToggle = document.querySelector(".sidebar-toggle");
const adminSidebar = document.querySelector(".admin-sidebar");

if (sidebarToggle && adminSidebar) {
    sidebarToggle.addEventListener("click", () => {
        const expanded = sidebarToggle.getAttribute("aria-expanded") === "true";
        sidebarToggle.setAttribute("aria-expanded", String(!expanded));
        adminSidebar.classList.toggle("open", !expanded);
    });
}

if (flashMessage) {
    window.setTimeout(() => {
        flashMessage.style.transition = "opacity 180ms ease, transform 180ms ease";
        flashMessage.style.opacity = "0";
        flashMessage.style.transform = "translateY(-8px)";
    }, 4200);
}
