const siteHeader = document.querySelector(".site-header");
const menuToggle = document.querySelector(".menu-toggle");
const flashMessage = document.querySelector(".flash");

if (siteHeader && menuToggle) {
    menuToggle.addEventListener("click", () => {
        const expanded = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", String(!expanded));
        siteHeader.classList.toggle("menu-open", !expanded);
    });
}

const sidebarToggle = document.querySelector(".sidebar-toggle");
const adminSidebar = document.querySelector(".admin-sidebar");

if (sidebarToggle && adminSidebar) {
    sidebarToggle.addEventListener("click", () => {
        const expanded = sidebarToggle.getAttribute("aria-expanded") === "true";
        sidebarToggle.setAttribute("aria-expanded", String(!expanded));
        adminSidebar.classList.toggle("open", !expanded);
    });
}

if (flashMessage) {
    window.setTimeout(() => {
        flashMessage.style.transition = "opacity 180ms ease, transform 180ms ease";
        flashMessage.style.opacity = "0";
        flashMessage.style.transform = "translateY(-8px)";
    }, 4200);
}

// Auth Modal for Guest Users adding items to Cart
const authModal = document.getElementById("authModal");
if (authModal) {
    const showModal = () => {
        authModal.classList.add("open");
        authModal.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden"; // Prevent scrolling behind modal
    };
    
    const hideModal = () => {
        authModal.classList.remove("open");
        authModal.setAttribute("aria-hidden", "true");
        document.body.style.overflow = ""; // Re-enable scrolling
    };
    
    // Expose showModal globally
    window.showAuthModal = (e) => {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        showModal();
    };
    
    // Close modal if clicking overlay background
    authModal.addEventListener("click", (e) => {
        if (e.target === authModal) {
            hideModal();
        }
    });
    
    // Close modal on Escape key press
    window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && authModal.classList.contains("open")) {
            hideModal();
        }
    });

    // Intercept forms adding to cart if user is not logged in (fallback)
    if (window.isLoggedIn === false) {
        document.addEventListener("submit", (e) => {
            const form = e.target;
            if (form && form.action && form.action.includes("cart.php")) {
                const actionInput = form.querySelector('input[name="action"]');
                if (actionInput && actionInput.value === "add") {
                    e.preventDefault(); // Stop submission to cart.php
                    showModal();
                }
            }
        });
    }
}

// Theme Switcher Logic
const themeToggles = document.querySelectorAll(".theme-toggle-btn");
themeToggles.forEach(toggle => {
    toggle.addEventListener("click", () => {
        const currentTheme = document.documentElement.getAttribute("data-theme") || "light";
        const newTheme = currentTheme === "dark" ? "light" : "dark";
        
        document.documentElement.setAttribute("data-theme", newTheme);
        localStorage.setItem("theme", newTheme);
    });
});

