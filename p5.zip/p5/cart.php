<?php
require_once __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $product_id = filter_var($_POST['product_id'] ?? 0, FILTER_VALIDATE_INT);
    $_SESSION['cart'] = $_SESSION['cart'] ?? [];

    if ($action === 'add' && $product_id) {
        require_login();
        $statement = $pdo->prepare("SELECT product_id FROM products WHERE product_id = ? AND status = 'available' AND stock_quantity > 0");
        $statement->execute([$product_id]);
        if ($statement->fetch()) {
            $_SESSION['cart'][$product_id] = ($_SESSION['cart'][$product_id] ?? 0) + 1;
            set_flash('success', 'Product added to cart.');
        }
        redirect_back();
    } elseif ($action === 'update' && !empty($_POST['quantity']) && is_array($_POST['quantity'])) {
        $updated_id = null;
        foreach ($_POST['quantity'] as $id => $quantity) {
            $safe_id = filter_var($id, FILTER_VALIDATE_INT);
            $safe_quantity = max(1, min(99, (int) $quantity));
            if ($safe_id && isset($_SESSION['cart'][$safe_id])) {
                $_SESSION['cart'][$safe_id] = $safe_quantity;
                $updated_id = $safe_id;
            }
        }
        set_flash('success', 'Record Updated');
        redirect('cart.php' . ($updated_id ? '#item-' . $updated_id : ''));
    } elseif ($action === 'remove' && $product_id) {
        unset($_SESSION['cart'][$product_id]);
        set_flash('success', 'Record Deleted');
    }
    redirect('cart.php');
}

$cart = $_SESSION['cart'] ?? [];
$products = [];
$subtotal = 0;
if ($cart) {
    $ids = array_map('intval', array_keys($cart));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $statement = $pdo->prepare("SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id WHERE p.product_id IN ({$placeholders})");
    $statement->execute($ids);
    $products = $statement->fetchAll();
    foreach ($products as $product) $subtotal += $product['price'] * $cart[$product['product_id']];
}
$shipping = $subtotal > 0 ? 89 : 0;
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];
$page_title = 'Cart';
require __DIR__ . '/includes/header.php';
?>
<section class="shell standard-page narrow-page">
    <header class="page-heading"><span class="eyebrow">YOUR BAG</span><h1>Cart (<?= cart_count() ?>)</h1><p>Review your patches, adjust quantities, and continue when everything looks right.</p></header>
    <div class="cart-layout">
        <div class="cart-list">
            <?php if (!$products): ?><div class="empty-state"><b>○</b><h2>Your cart is ready for a fresh start.</h2><a class="button primary" href="store.php">Browse products</a></div><?php endif; ?>
            <?php foreach ($products as $index => $product): ?>
                <article class="cart-item" id="item-<?= (int) $product['product_id'] ?>">
                    <?php
                        $visual_tone = ['aqua','violet','lime','blue','coral'][$index % 5];
                        $image_key = strtolower(str_replace(' ', '', $product['category_name']));
                        $image_file = $category_images[$image_key] ?? null;
                    ?>
                    <div class="product-visual tone-<?= e($visual_tone) ?>">
                        <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="<?= e($product['product_name']) ?>"><?php endif; ?>
                    </div>
                    <div><small><?= e(strtoupper($product['category_name'])) ?></small><h3><?= e($product['product_name']) ?></h3><span><?= (int) $product['stock_quantity'] ?> in stock</span><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button class="remove-button">Remove</button></form></div>
                    <form class="quantity-form" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="number" name="quantity[<?= (int) $product['product_id'] ?>]" min="1" max="<?= (int) $product['stock_quantity'] ?>" value="<?= (int) $cart[$product['product_id']] ?>"><button>Update</button></form>
                    <strong><?= format_price($product['price'] * $cart[$product['product_id']]) ?></strong>
                </article>
            <?php endforeach; ?>
        </div>
        <aside class="order-summary"><span class="eyebrow">ORDER SUMMARY</span><h2>Ready when you are.</h2><p><span>Subtotal</span><strong><?= format_price($subtotal) ?></strong></p><p><span>Shipping</span><strong><?= $shipping ? format_price($shipping) : '—' ?></strong></p><div><span>Total</span><strong><?= format_price($subtotal + $shipping) ?></strong></div><?php if ($products): ?><a class="button primary" href="checkout.php">Continue to checkout</a><?php endif; ?><small>▣ Secure classroom-demo checkout</small></aside>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>