<?php
require_once __DIR__ . '/includes/bootstrap.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || $password === '') {
        $error = 'Enter a valid email and password.';
    } else {
        $statement = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $account = $statement->fetch();

        if ($account && (int) $account['is_active'] === 1 && password_verify($password, $account['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'user_id' => $account['user_id'],
                'fullname' => $account['fullname'],
                'email' => $account['email'],
                'role' => $account['role'],
            ];
            add_audit_log($pdo, $account['user_id'], 'Login Success', 'User signed in successfully.');
            set_flash('success', 'Login Success');
            redirect($account['role'] === 'admin' ? 'admin/dashboard.php' : 'store.php');
        }
        $error = 'Incorrect credentials or inactive account.';
    }
}

$page_title = 'Login';
require __DIR__ . '/includes/header.php';
?>
<section class="auth-page shell login-page">
    <aside class="auth-art"><span class="eyebrow">TEAM AQUABYTE</span><h2>Small cues can create healthier days.</h2><p>Sign in to shop or manage the HydraPatch PH project.</p><?php $visual_category = 'STUDENT'; $visual_tone = 'violet'; require __DIR__ . '/includes/product_visual.php'; ?></aside>
    <form class="auth-form" method="post">
        <?= csrf_field() ?>
        <span class="eyebrow">WELCOME BACK</span><h1>Sign in to continue.</h1><p>Access your cart, orders, or seller dashboard.</p>
        <?php if ($error): ?><div class="error-list"><span><?= e($error) ?></span></div><?php endif; ?>
        <label>Email address<input name="email" required type="email" value="<?= old('email') ?>"></label>
        <label>Password<input name="password" required type="password" minlength="8"></label>
        <button class="button primary" type="submit">Sign in securely →</button>
        <p class="switch-link">New to HydraPatch? <a href="register.php">Create an account</a></p>
    </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
