<?php
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . $path);
    exit;
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash()
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function old($key, $default = '')
{
    return e($_POST[$key] ?? $default);
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e($_SESSION['csrf_token']) . '">';
}

function verify_csrf()
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $submitted)) {
        http_response_code(419);
        exit('Invalid form request. Please return to the previous page and try again.');
    }
}

function is_logged_in()
{
    return !empty($_SESSION['user']);
}

function is_admin()
{
    return isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin';
}

function require_login($login_path = 'login.php')
{
    if (!is_logged_in()) {
        set_flash('error', 'Please sign in before continuing.');
        redirect($login_path);
    }
}

function require_admin($login_path = '../login.php')
{
    if (!is_admin()) {
        set_flash('error', 'Administrator access is required.');
        redirect($login_path);
    }
}

function cart_count()
{
    return array_sum($_SESSION['cart'] ?? []);
}

function add_audit_log($pdo, $user_id, $action, $details = '')
{
    $statement = $pdo->prepare(
        'INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)'
    );
    $statement->execute([$user_id, $action, $details]);
}

function format_price($amount)
{
    return '₱' . number_format((float) $amount, 2);
}

function order_code()
{
    return 'HP-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
}
