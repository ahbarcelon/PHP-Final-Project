<section class="admin-shell shell-wide">
    <aside class="admin-sidebar">
        <div class="admin-profile"><b><?= e(strtoupper(substr($_SESSION['user']['fullname'], 0, 1))) ?></b><span><strong><?= e($_SESSION['user']['fullname']) ?></strong><small>Administrator</small></span></div>
        <nav>
            <a class="<?= $admin_section === 'dashboard' ? 'active' : '' ?>" href="dashboard.php">⌂ Dashboard</a>
            <a class="<?= $admin_section === 'products' ? 'active' : '' ?>" href="products.php">▦ Products & stock</a>
            <a class="<?= $admin_section === 'users' ? 'active' : '' ?>" href="users.php">◎ User management</a>
            <a class="<?= $admin_section === 'reports' ? 'active' : '' ?>" href="reports.php">↗ Reports & audit</a>
        </nav>
        <small class="secure-admin">● SECURE ADMIN AREA</small>
    </aside>
    <div class="admin-main">
