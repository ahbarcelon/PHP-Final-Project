<?php
$page_title = $page_title ?? 'HydraPatch PH';
$base_path = $base_path ?? '';
$active_page = $active_page ?? '';
$flash = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="HydraPatch PH educational health-tech store project">
    <title><?= e($page_title) ?> | HydraPatch PH</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Sora:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e($base_path) ?>assets/css/style.css">
</head>
<body>
<div class="announcement">HydraPatch PH is an educational health-tech concept <span>Free delivery over ₱1,000 • Metro Manila</span></div>
<header class="site-header">
    <a class="brand" href="<?= e($base_path) ?>index.php" aria-label="HydraPatch PH home">
        <span class="logo-mark"><i></i><b>⌁</b></span>
        <span><strong>HydraPatch</strong><small>PH • TEAM AQUABYTE</small></span>
    </a>
    <button class="menu-toggle" type="button" aria-label="Open navigation" aria-expanded="false">☰</button>
    <nav class="main-nav" aria-label="Main navigation">
        <a class="<?= $active_page === 'home' ? 'active' : '' ?>" href="<?= e($base_path) ?>index.php">Home</a>
        <a class="<?= $active_page === 'store' ? 'active' : '' ?>" href="<?= e($base_path) ?>store.php">Shop</a>
        <a class="<?= $active_page === 'about' ? 'active' : '' ?>" href="<?= e($base_path) ?>about.php">Our story</a>
        <?php if (is_admin()): ?>
            <a class="<?= $active_page === 'admin' ? 'active' : '' ?>" href="<?= e($base_path) ?>admin/dashboard.php">Seller panel</a>
        <?php endif; ?>
    </nav>
    <div class="header-actions">
        <?php if (is_logged_in()): ?>
            <span class="welcome">Hi, <?= e(explode(' ', $_SESSION['user']['fullname'])[0]) ?></span>
            <a class="text-button" href="<?= e($base_path) ?>logout.php">Logout</a>
        <?php else: ?>
            <a class="text-button" href="<?= e($base_path) ?>login.php">Sign in</a>
        <?php endif; ?>
        <a class="cart-link" href="<?= e($base_path) ?>cart.php" aria-label="Shopping cart">▱ <b><?= cart_count() ?></b></a>
    </div>
</header>
<?php if ($flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?>" role="status"><b>✓</b><?= e($flash['message']) ?></div>
<?php endif; ?>
<main>
