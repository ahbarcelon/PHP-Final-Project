<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

$total_products = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$low_stock = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE stock_quantity <= 10')->fetchColumn();
$total_users = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$sales = (float) $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE order_status <> 'cancelled'")->fetchColumn();
$inventory = $pdo->query('SELECT product_name, stock_quantity FROM products ORDER BY stock_quantity')->fetchAll();
$recent = $pdo->query('SELECT a.*, u.fullname FROM audit_logs a JOIN users u ON u.user_id = a.user_id ORDER BY a.created_at DESC LIMIT 5')->fetchAll();

$page_title = 'Admin Dashboard';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'dashboard';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">OVERVIEW • <?= strtoupper(date('d F Y')) ?></span><h1>Good day, <?= e(explode(' ', $_SESSION['user']['fullname'])[0]) ?>.</h1></div><a class="button small" href="reports.php">Generate report</a></header>
<div class="metric-grid">
    <article><span>TOTAL PRODUCTS</span><strong><?= $total_products ?></strong><small>Live catalog records</small><b>▦</b></article>
    <article class="warning"><span>LOW STOCK</span><strong><?= $low_stock ?></strong><small>Needs attention</small><b>!</b></article>
    <article><span>REGISTERED USERS</span><strong><?= $total_users ?></strong><small>Customer + admin accounts</small><b>◎</b></article>
    <article><span>TOTAL SALES</span><strong><?= format_price($sales) ?></strong><small>Non-cancelled orders</small><b>↗</b></article>
</div>
<div class="dashboard-grid">
    <section class="admin-card sales-card"><div class="card-title"><div><span class="eyebrow">SALES OVERVIEW</span><h2>Order activity</h2></div><small>MySQL data</small></div><div class="bar-chart"><?php foreach ([38, 57, 44, 70, 62, 85, 76, 94, 69, 83, 91, 100] as $bar): ?><i style="height: <?= $bar ?>%"></i><?php endforeach; ?></div></section>
    <section class="admin-card"><div class="card-title"><div><span class="eyebrow">INVENTORY HEALTH</span><h2>Stock by product</h2></div></div><div class="stock-list"><?php foreach ($inventory as $item): ?><div><span><?= e(str_replace('HydraPatch ', '', $item['product_name'])) ?></span><i><b class="<?= $item['stock_quantity'] <= 10 ? 'warning' : '' ?>" style="width: <?= min(100, (int) $item['stock_quantity'] * 2) ?>%"></b></i><strong><?= (int) $item['stock_quantity'] ?></strong></div><?php endforeach; ?></div><a class="text-link" href="products.php">Manage inventory →</a></section>
    <section class="admin-card activity-card"><div class="card-title"><div><span class="eyebrow">RECENT ACTIVITY</span><h2>Latest system actions</h2></div><a href="reports.php">Full audit log</a></div><div class="table-wrap"><table><thead><tr><th>User</th><th>Action</th><th>Details</th><th>Time</th></tr></thead><tbody><?php foreach ($recent as $log): ?><tr><td><?= e($log['fullname']) ?></td><td><span class="action-pill"><?= e($log['action']) ?></span></td><td><?= e($log['details']) ?></td><td><?= e(date('M d, g:i A', strtotime($log['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
</div>
<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/footer.php'; ?>
