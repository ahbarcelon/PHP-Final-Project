<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

if (($_GET['export'] ?? '') === 'audit') {
    $logs = $pdo->query('SELECT a.log_id, u.fullname, a.action, a.details, a.created_at FROM audit_logs a JOIN users u ON u.user_id = a.user_id ORDER BY a.created_at DESC')->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="hydrapatch-audit-log.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Log ID', 'User', 'Action', 'Details', 'Created At']);
    foreach ($logs as $log) fputcsv($output, $log);
    fclose($output);
    exit;
}

$total_inventory = (int) $pdo->query('SELECT COALESCE(SUM(stock_quantity), 0) FROM products')->fetchColumn();
$low_stock = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE stock_quantity <= 10')->fetchColumn();
$sales = (float) $pdo->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE order_status <> 'cancelled'")->fetchColumn();
$inventory = $pdo->query('SELECT p.product_name, c.category_name, p.stock_quantity, p.price, p.status FROM products p JOIN categories c ON c.category_id = p.category_id ORDER BY p.stock_quantity')->fetchAll();
$orders = $pdo->query('SELECT order_code, total_amount, payment_method, payment_status, order_status, created_at FROM orders ORDER BY created_at DESC LIMIT 20')->fetchAll();
$logs = $pdo->query('SELECT a.*, u.fullname FROM audit_logs a JOIN users u ON u.user_id = a.user_id ORDER BY a.created_at DESC LIMIT 100')->fetchAll();

$page_title = 'Reports & Audit';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'reports';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">DATA & ACCOUNTABILITY</span><h1>Reports & audit log</h1></div><a class="button small" href="reports.php?export=audit">Export audit CSV</a></header>
<div class="report-grid"><article><span>REMAINING INVENTORY</span><strong><?= $total_inventory ?> <small>units</small></strong><p>Across all active products</p></article><article class="warning"><span>LOW-STOCK REPORT</span><strong><?= $low_stock ?> <small>items</small></strong><p>At or below the 10-unit threshold</p></article><article><span>SALES SUMMARY</span><strong><?= format_price($sales) ?></strong><p>All non-cancelled orders</p></article></div>
<section class="admin-card report-section"><div class="card-title"><div><span class="eyebrow">REMAINING INVENTORY REPORT</span><h2>Current stock position</h2></div></div><div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Price</th><th>Status</th></tr></thead><tbody><?php foreach ($inventory as $item): ?><tr><td><strong><?= e($item['product_name']) ?></strong></td><td><?= e($item['category_name']) ?></td><td><?= (int) $item['stock_quantity'] ?></td><td><?= format_price($item['price']) ?></td><td><span class="status <?= $item['stock_quantity'] <= 10 ? 'low' : '' ?>"><?= e(str_replace('_', ' ', $item['status'])) ?></span></td></tr><?php endforeach; ?></tbody></table></div></section>
<section class="admin-card report-section"><div class="card-title"><div><span class="eyebrow">SALES SUMMARY</span><h2>Recent orders</h2></div></div><div class="table-wrap"><table><thead><tr><th>Order</th><th>Amount</th><th>Payment</th><th>Payment status</th><th>Order status</th><th>Date</th></tr></thead><tbody><?php if (!$orders): ?><tr><td colspan="6">No order records yet.</td></tr><?php endif; ?><?php foreach ($orders as $order): ?><tr><td><strong><?= e($order['order_code']) ?></strong></td><td><?= format_price($order['total_amount']) ?></td><td><?= e(str_replace('_', ' ', $order['payment_method'])) ?></td><td><?= e($order['payment_status']) ?></td><td><?= e($order['order_status']) ?></td><td><?= e(date('M d, Y', strtotime($order['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<section class="admin-card report-section"><div class="card-title"><div><span class="eyebrow">ACCOUNTABILITY TRAIL</span><h2>Audit log report</h2></div><a href="reports.php?export=audit">Download CSV</a></div><div class="table-wrap"><table><thead><tr><th>User</th><th>Action</th><th>Details</th><th>Time</th></tr></thead><tbody><?php if (!$logs): ?><tr><td colspan="4">No audit records yet.</td></tr><?php endif; ?><?php foreach ($logs as $log): ?><tr><td><strong><?= e($log['fullname']) ?></strong></td><td><span class="action-pill"><?= e($log['action']) ?></span></td><td><?= e($log['details']) ?></td><td><?= e(date('M d, Y g:i A', strtotime($log['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/footer.php'; ?>
