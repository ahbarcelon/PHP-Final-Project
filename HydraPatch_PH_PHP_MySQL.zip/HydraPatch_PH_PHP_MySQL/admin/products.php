<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin('../login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $product_id = filter_var($_POST['product_id'] ?? 0, FILTER_VALIDATE_INT);
    try {
        if ($action === 'add' || $action === 'edit') {
            $name = trim($_POST['product_name'] ?? '');
            $category_id = filter_var($_POST['category_id'] ?? 0, FILTER_VALIDATE_INT);
            $description = trim($_POST['description'] ?? '');
            $price = filter_var($_POST['price'] ?? 0, FILTER_VALIDATE_FLOAT);
            $stock = filter_var($_POST['stock_quantity'] ?? 0, FILTER_VALIDATE_INT);
            if (!$category_id || strlen($name) < 3 || strlen($description) < 10 || $price < 0 || $stock < 0) throw new Exception('Please complete the product form correctly.');
            $status = $stock > 0 ? 'available' : 'out_of_stock';
            if ($action === 'add') {
                $statement = $pdo->prepare('INSERT INTO products (category_id, product_name, description, price, stock_quantity, status) VALUES (?, ?, ?, ?, ?, ?)');
                $statement->execute([$category_id, $name, $description, $price, $stock, $status]);
                add_audit_log($pdo, $_SESSION['user']['user_id'], 'added product', "Added {$name} with {$stock} units.");
                set_flash('success', 'Record Added');
            } else {
                $statement = $pdo->prepare('UPDATE products SET category_id = ?, product_name = ?, description = ?, price = ?, stock_quantity = ?, status = ? WHERE product_id = ?');
                $statement->execute([$category_id, $name, $description, $price, $stock, $status, $product_id]);
                add_audit_log($pdo, $_SESSION['user']['user_id'], 'edited price / product', "Updated {$name}; price {$price}; stock {$stock}.");
                set_flash('success', 'Record Updated');
            }
        } elseif ($action === 'stock' && $product_id) {
            $statement = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity + 5, status = 'available' WHERE product_id = ?");
            $statement->execute([$product_id]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'updated stock', "Added 5 units to product #{$product_id}.");
            set_flash('success', 'Record Updated');
        } elseif ($action === 'out' && $product_id) {
            $statement = $pdo->prepare("UPDATE products SET status = 'out_of_stock' WHERE product_id = ?");
            $statement->execute([$product_id]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'updated stock', "Marked product #{$product_id} out of stock.");
            set_flash('success', 'Record Updated');
        } elseif ($action === 'delete' && $product_id) {
            $statement = $pdo->prepare('DELETE FROM products WHERE product_id = ?');
            $statement->execute([$product_id]);
            add_audit_log($pdo, $_SESSION['user']['user_id'], 'deleted product', "Deleted product #{$product_id}.");
            set_flash('success', 'Record Deleted');
        }
    } catch (Throwable $error) {
        set_flash('error', $error instanceof PDOException && $error->getCode() === '23000' ? 'This product is linked to an order and cannot be deleted.' : $error->getMessage());
    }
    redirect('products.php');
}

$edit_product = null;
if (!empty($_GET['edit'])) {
    $statement = $pdo->prepare('SELECT * FROM products WHERE product_id = ?');
    $statement->execute([(int) $_GET['edit']]);
    $edit_product = $statement->fetch();
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $statement = $pdo->prepare('SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id WHERE p.product_name LIKE ? ORDER BY p.product_id');
    $statement->execute(['%' . $search . '%']);
    $products = $statement->fetchAll();
} else {
    $products = $pdo->query('SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id ORDER BY p.product_id')->fetchAll();
}
$categories = $pdo->query('SELECT * FROM categories ORDER BY category_id')->fetchAll();

$page_title = 'Products & Stock';
$base_path = '../';
$active_page = 'admin';
$admin_section = 'products';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/admin_nav.php';
?>
<header class="admin-heading"><div><span class="eyebrow">INVENTORY MANAGEMENT</span><h1>Products & stock</h1></div><span class="record-badge">● <?= count($products) ?> records</span></header>
<?php if ($search !== ''): ?><div class="search-result">Search Result: <?= count($products) ?> product record(s)</div><?php endif; ?>
<div class="manage-grid">
    <section class="admin-card form-card"><span class="eyebrow"><?= $edit_product ? 'UPDATE CATALOG ITEM' : 'NEW CATALOG ITEM' ?></span><h2><?= $edit_product ? 'Edit product' : 'Add product' ?></h2>
        <form class="admin-form" method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="<?= $edit_product ? 'edit' : 'add' ?>"><input type="hidden" name="product_id" value="<?= (int) ($edit_product['product_id'] ?? 0) ?>">
            <label>Product name<input name="product_name" required value="<?= e($edit_product['product_name'] ?? '') ?>"></label>
            <label>Category<select name="category_id"><?php foreach ($categories as $category): ?><option value="<?= (int) $category['category_id'] ?>" <?= (int) ($edit_product['category_id'] ?? 0) === (int) $category['category_id'] ? 'selected' : '' ?>><?= e($category['category_name']) ?></option><?php endforeach; ?></select></label>
            <label>Description<textarea name="description" required><?= e($edit_product['description'] ?? '') ?></textarea></label>
            <div class="form-grid"><label>Price<input name="price" type="number" min="0" step="0.01" required value="<?= e($edit_product['price'] ?? '') ?>"></label><label>Stock<input name="stock_quantity" type="number" min="0" required value="<?= e($edit_product['stock_quantity'] ?? '') ?>"></label></div>
            <button class="button primary"><?= $edit_product ? 'Save changes' : 'Add product' ?></button><?php if ($edit_product): ?><a class="cancel-link" href="products.php">Cancel editing</a><?php endif; ?>
        </form>
    </section>
    <section class="admin-card table-card"><div class="card-title"><div><span class="eyebrow">LIVE INVENTORY</span><h2>Product records</h2></div><form class="admin-search" method="get"><input name="q" value="<?= e($search) ?>" placeholder="Search products"><button>⌕</button></form></div><div class="table-wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach ($products as $product): ?><tr><td><strong><?= e($product['product_name']) ?></strong><small><?= e($product['category_name']) ?></small></td><td><?= format_price($product['price']) ?></td><td><?= (int) $product['stock_quantity'] ?></td><td><span class="status <?= $product['status'] !== 'available' || $product['stock_quantity'] <= 10 ? 'low' : '' ?>"><?= e(str_replace('_', ' ', $product['status'])) ?></span></td><td><div class="table-actions"><a href="products.php?edit=<?= (int) $product['product_id'] ?>">Edit</a><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="stock"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button>+5 stock</button></form><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="out"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button>Out</button></form><form method="post" onsubmit="return confirm('Delete this product record?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="product_id" value="<?= (int) $product['product_id'] ?>"><button class="danger">Delete</button></form></div></td></tr><?php endforeach; ?></tbody></table></div></section>
</div>
<?php require __DIR__ . '/../includes/admin_end.php'; require __DIR__ . '/../includes/footer.php'; ?>
