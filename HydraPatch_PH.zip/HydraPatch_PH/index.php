<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Smarter Daily Wellness';
$active_page = 'home';
$products = $pdo->query('SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id ORDER BY p.product_id')->fetchAll();
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];
require __DIR__ . '/includes/header.php';
?>
<section class="hero shell">
    <div class="hero-copy">
        <span class="eyebrow">● SMARTER DAILY WELLNESS</span>
        <h1>Hydration awareness,<br><em>made effortless.</em></h1>
        <p>Meet the everyday patch concept designed to help students, professionals, athletes, and families stay mindful of hydration—without interrupting the day.</p>
        <div class="button-row"><a class="button primary" href="shop.php">Shop patches →</a><a class="button secondary" href="about.php">How it works</a></div>
        <div class="trust-row"><span>✓ Skin-friendly concept</span><span>✓ Beginner-friendly PHP build</span></div>
    </div>
    <div class="hero-product">
        <div class="hero-halo"></div>
        <?php
            $visual_category = 'DAILY'; $visual_tone = 'aqua';
            $image_file = $category_images[strtolower($visual_category)] ?? null;
        ?>
        <div class="product-visual tone-<?= e($visual_tone) ?>">
            <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="Daily patch"><?php endif; ?>
        </div>
        <aside><b>98%</b><small>fits real daily routines</small></aside>
    </div>
</section>
<section class="proof-strip"><small>DESIGNED FOR REAL LIFE</small><strong>Study.</strong><i>•</i><strong>Work.</strong><i>•</i><strong>Train.</strong><i>•</i><strong>Thrive.</strong></section>
<section class="shell section-space">
    <div class="section-heading"><div><span class="eyebrow">FIND YOUR FIT</span><h2>A patch for every pace.</h2></div><a href="shop.php">Explore the full collection →</a></div>
    <div class="product-grid">
        <?php foreach ($products as $index => $product): ?>
            <article class="product-card">
                <?php
                    $visual_category = strtoupper($product['category_name']);
                    $tones = ['aqua', 'violet', 'lime', 'blue', 'coral'];
                    $visual_tone = $tones[((int) $product['category_id'] - 1) % 5];
                    $image_key = strtolower(str_replace(' ', '', $product['category_name']));
                    $image_file = $category_images[$image_key] ?? null;
                ?>
                <div class="product-visual tone-<?= e($visual_tone) ?>">
                    <?php if ($image_file): ?><img class="product-photo" src="products/<?= e($image_file) ?>" alt="<?= e($product['product_name']) ?>"><?php endif; ?>
                </div>
                <div class="product-info"><small><?= e($visual_category) ?> • WELLNESS</small><h3><?= e($product['product_name']) ?></h3><p><?= e($product['description']) ?></p><div><strong><?= format_price($product['price']) ?></strong><a class="round-button" href="product.php?id=<?= (int) $product['product_id'] ?>">→</a></div></div>
            </article>
        <?php endforeach; ?>
    </div>
</section>
<section class="how-section shell"><div><span class="eyebrow">SIMPLE BY DESIGN</span><h2>Wellness that moves with you.</h2><p>Peel, place, and carry on. This classroom product concept turns hydration awareness into an easy daily habit.</p></div><div class="step-grid"><article><b>01</b><h3>Choose</h3><p>Pick the patch made for your routine.</p></article><article><b>02</b><h3>Place</h3><p>Apply the lightweight patch concept.</p></article><article><b>03</b><h3>Stay mindful</h3><p>Use the visual cue as your reminder.</p></article></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>