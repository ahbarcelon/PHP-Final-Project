<?php
$visual_category = $visual_category ?? 'DAILY';
$visual_tone = $visual_tone ?? 'aqua';
$category_images = [
    'daily' => 'Daily.png',
    'student' => 'Student.png',
    'sport' => 'Sport.png',
    'office' => 'Office.png',
    'familypack' => 'FamilyPack.png',
];
$image_key = strtolower(str_replace(' ', '', $visual_category));
$image_file = $category_images[$image_key] ?? null;
?>
<div class="product-visual tone-<?= e($visual_tone) ?>" aria-label="HydraPatch <?= e($visual_category) ?> concept image">
    <?php if ($image_file): ?>
        <img class="product-photo" src="products/<?= e($image_file) ?>" alt="HydraPatch <?= e($visual_category) ?>">
    <?php else: ?>
        <span class="visual-grid"></span>
        <span class="patch-shadow"></span>
        <span class="patch-body"><small>HYDRA</small><b>∿</b><i><?= e(strtoupper($visual_category)) ?></i></span>
        <span class="micro-copy">SMART HYDRATION PATCH</span>
    <?php endif; ?>
</div>
